// shop-common.js — أدوات عامة للواجهة
(function(w){
  const qs = (k)=> new URLSearchParams(location.search).get(k);
  const fmt = (n)=> (Number(n||0).toFixed(3) + ' ر.ع');
  w.Shop = { qs, fmt };
})(window);