// shop-checkout.js — صفحة الدفع (Placeholder)
(function(){
  const el = document.getElementById('checkoutMount');
  el.innerHTML = 'TODO: استخدم مفاتيح Thawani من bh_settings لإنشاء جلسة دفع عبر خادمك.';
})();