// shop-home.js — منطق الصفحة الرئيسية (عرض مختارات بسيطة)
(function(){
  const grid = document.getElementById('homeGrid');
  const list = (window.ShopData?.getProducts()||[]).slice(0,8);
  grid.innerHTML = list.map(p=>(
    '<article class="card">'+
      '<div class="media"></div>'+
      '<div class="info"><div class="muted">'+(p.name||p.sku)+'</div>'+
      '<a class="btn" href="product.html?sku='+encodeURIComponent(p.sku)+'">عرض</a></div>'+
    '</article>'
  )).join('');
})();