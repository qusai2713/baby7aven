
(function(){
  'use strict';
  const qs=(s,p=document)=>p.querySelector(s);
  const qsa=(s,p=document)=>Array.from(p.querySelectorAll(s));
  function openMenu(){ qs('#mobileWrap')?.setAttribute('aria-hidden','false'); qs('#mobileMenuClose')?.focus(); }
  function closeMenu(){ qs('#mobileWrap')?.setAttribute('aria-hidden','true'); qs('#burger')?.focus(); }
  document.addEventListener('DOMContentLoaded', () => {
    qs('#burger')?.addEventListener('click', openMenu);
    qs('#mobileMenuClose')?.addEventListener('click', closeMenu);
    qs('#mobileBackdrop')?.addEventListener('click', closeMenu);
    document.addEventListener('keyup', (e)=>{ if(e.key==='Escape') closeMenu(); });
  });
})();
