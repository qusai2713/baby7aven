// shop-cart.js — سلة مبسطة (Placeholder)
(function(){
  const mount = document.getElementById('cartView');
  mount.innerHTML = 'TODO: اربط إضافة المنتجات للسلة وتحديث الإجمالي.';
})();