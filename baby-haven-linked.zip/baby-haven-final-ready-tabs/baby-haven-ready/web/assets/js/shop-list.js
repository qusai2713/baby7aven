// shop-list.js — صفحة المنتجات (بحث بسيط + قائمة)
(function(){
  const grid = document.getElementById('listGrid');
  const qInp = document.getElementById('q');
  const fltType = document.getElementById('fltType');
  const src = (window.ShopData?.getProducts()||[]);
  function render(){
    const q = (qInp.value||'').toLowerCase();
    const t = fltType.value||'all';
    const list = src.filter(p=>{
      const hitQ = (!q) || String(p.name||p.sku||'').toLowerCase().includes(q) || String(p.sku||'').toLowerCase().includes(q);
      const hitT = (t==='all') || (p.type===t);
      return hitQ && hitT;
    });
    grid.innerHTML = list.map(p=>(
      '<article class="card">'+
        '<div class="media"></div>'+
        '<div class="info"><div class="muted">'+(p.name||p.sku)+'</div>'+
        '<a class="btn" href="product.html?sku='+encodeURIComponent(p.sku)+'">تفاصيل</a></div>'+
      '</article>'
    )).join('');
  }
  qInp.addEventListener('input', render);
  fltType.addEventListener('change', render);
  render();
})();