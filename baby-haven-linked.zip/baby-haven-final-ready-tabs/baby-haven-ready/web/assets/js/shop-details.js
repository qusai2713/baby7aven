// shop-details.js — صفحة تفاصيل المنتج
(function(){
  const sku = window.Shop.qs('sku');
  const mount = document.getElementById('productView');
  const item = (window.ShopData?.getProducts()||[]).find(p=> String(p.sku).toLowerCase()===String(sku||'').toLowerCase());
  if(!item){ mount.innerHTML = 'لم يتم العثور على المنتج.'; return; }
  const priceLine = item.type==='simple' ? ('<div><b>السعر:</b> '+window.Shop.fmt(item.price||0)+'</div>') : '';
  mount.innerHTML = [
    '<h1>'+(item.name||item.sku)+'</h1>',
    '<div><b>SKU:</b> '+item.sku+'</div>',
    '<div><b>القسم:</b> '+(item.section||'-')+'</div>',
    '<div><b>الفئة:</b> '+(item.category||'-')+'</div>',
    priceLine,
    '<div style="margin-top:10px"><a class="btn" href="cart.html">أضف للسلة</a></div>'
  ].join('');
})();