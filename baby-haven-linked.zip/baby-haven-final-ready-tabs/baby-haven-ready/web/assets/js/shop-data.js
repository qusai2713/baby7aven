// shop-data.js — جسر بيانات: يقرأ من localStorage الذي تديره لوحة التحكم
(function(w){
  const KEYS = { PRODUCTS:'bh_admin_products_v35', SECTIONS:'bh_sections_v10', CATEGORIES:'bh_categories_v10' };
  const read = (k, fb)=>{ try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(fb));}catch{return fb;} };
  const getProducts = ()=> read(KEYS.PRODUCTS, []);
  const getSections = ()=> read(KEYS.SECTIONS, []);
  const getCategories = ()=> read(KEYS.CATEGORIES, []);
  w.ShopData = { getProducts, getSections, getCategories };
})(window);