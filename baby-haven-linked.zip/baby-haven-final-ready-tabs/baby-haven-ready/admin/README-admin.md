# Header Block
File: README-admin.md
Purpose: دليل سريع لتشغيل لوحة التحكم — BabyHaven-admin-final

## تشغيل محلي
- افتح `admin.html` مباشرة في المتصفح أو عبر خادم بسيط (Live Server).
- الثيم: **theme-slate** (داكن).

## التبويبات
- orders/products/inventory/taxonomy/discounts/delivery/settings — كل تبويب في ملف JS مستقل داخل `assets/js/admin`.

## تخزين محلي
- المنتجات: `bh_products`
- سجل المخزون: `bh_inventory_log`
- التصنيف: `KEY_TAXONOMY`

بُني في: 2025-10-06T10:42:10.458123 UTC
