
/* admin.js — منتجات + متغيرات (ألوان/أحجام) + وصف نقاط + إلغاء بتأكيد + أقسام/فئات + إعدادات */
(function(){
  'use strict';
  const DB = window.StoreDB;
  const Settings = window.BHSettings;

  // ---------- Tabs ----------
  function showTab(name){
    document.getElementById('tab-products').style.display = (name==='products')?'block':'none';
    document.getElementById('tab-categories').style.display = (name==='categories')?'block':'none';
    document.getElementById('tab-settings').style.display = (name==='settings')?'block':'none';
    document.getElementById('tabBtnProducts').classList.toggle('ghost', name!=='products');
    document.getElementById('tabBtnCategories').classList.toggle('ghost', name!=='categories');
    document.getElementById('tabBtnSettings').classList.toggle('ghost', name!=='settings');
  }

  // ---------- State for current form ----------
  let currentColors = []; // [{label,image,price,qty}]
  let currentSizes  = []; // [{size,price,qty}]

  // ---------- Helpers ----------
  function $(id){ return document.getElementById(id); }
  function val(id){ const el=$(id); return (el && el.value)||''; }
  function toNum(v){ return Number(v||0); }

  function resetForm(){
    ['pName','pSku','pPrice','pQty','pDiscount','pImage','pDesc'].forEach(id=>$(id).value='');
    $('pType').value='simple';
    currentColors = [];
    currentSizes = [];
    renderVariants();
    populateTaxonomySelects();
    toggleVariantBlocks();
  }

  function populateTaxonomySelects(){
    const t = DB.loadTaxonomy();
    const pSection = $('pSection');
    const pCategory = $('pCategory');
    pSection.innerHTML = (t.sections||[]).map(s=>`<option value="${s.name}">${s.name}</option>`).join('');
    const first = (t.sections||[])[0];
    const cats = first ? (first.categories||[]) : [];
    pCategory.innerHTML = cats.map(c=>`<option value="${c}">${c}</option>`).join('');
    pSection.onchange = ()=>{
      const sec = pSection.value;
      const c = DB.listCategories(sec);
      pCategory.innerHTML = c.map(x=>`<option value="${x}">${x}</option>`).join('');
    };
  }

  function toggleVariantBlocks(){
    const type = $('pType').value;
    const wrap = $('variantsArea'), color = $('colorBlock'), size = $('sizeBlock');
    if(type==='multi-color' || type==='multi-size'){ wrap.style.display='block'; }
    else { wrap.style.display='none'; }
    color.style.display = (type==='multi-color') ? 'block' : 'none';
    size.style.display  = (type==='multi-size') ? 'block' : 'none';
  }

  // ---------- Variants rendering ----------
  function renderVariants(){
    // Colors
    const listC = $('colorList');
    listC.innerHTML = currentColors.map((c,idx)=>`
      <div class="variant-row">
        <img class="thumb" src="${c.image||''}" alt="">
        <input type="text" placeholder="اسم اللون" value="${c.label||''}" oninput="AdminUI.onColorField(${idx},'label',this.value)">
        <input type="number" step="0.001" placeholder="السعر" value="${c.price||''}" oninput="AdminUI.onColorField(${idx},'price',this.value)">
        <input type="number" placeholder="الكمية" value="${c.qty||''}" oninput="AdminUI.onColorField(${idx},'qty',this.value)">
        <div style="display:flex;gap:6px;align-items:center">
          <input type="text" placeholder="رابط الصورة" value="${c.image||''}" oninput="AdminUI.onColorField(${idx},'image',this.value)" style="width:220px">
          <button class="btn xs danger" onclick="AdminUI.removeColor(${idx})">حذف</button>
        </div>
      </div>
    `).join('');

    // Sizes
    const listS = $('sizeList');
    listS.innerHTML = currentSizes.map((s,idx)=>`
      <div class="variant-row size">
        <input type="text" placeholder="المقاس (مثال: S / 0-3M)" value="${s.size||''}" oninput="AdminUI.onSizeField(${idx},'size',this.value)">
        <input type="number" step="0.001" placeholder="السعر" value="${s.price||''}" oninput="AdminUI.onSizeField(${idx},'price',this.value)">
        <input type="number" placeholder="الكمية" value="${s.qty||''}" oninput="AdminUI.onSizeField(${idx},'qty',this.value)">
        <button class="btn xs danger" onclick="AdminUI.removeSize(${idx})">حذف</button>
      </div>
    `).join('');
  }

  function addColor(){ currentColors.push({label:'', image:'', price:'', qty:''}); renderVariants(); }
  function addSize(){ currentSizes.push({size:'', price:'', qty:''}); renderVariants(); }
  function removeColor(i){ currentColors.splice(i,1); renderVariants(); }
  function removeSize(i){ currentSizes.splice(i,1); renderVariants(); }
  function onColorField(i,k,v){ currentColors[i][k]=(k==='price'||k==='qty')?v:v; renderVariants(); }
  function onSizeField(i,k,v){ currentSizes[i][k]=(k==='price'||k==='qty')?v:v; renderVariants(); }

  // ---------- Save / Edit / Remove ----------
  function saveProduct(){
    const p = {
      name: val('pName').trim(),
      sku: val('pSku').trim(),
      type: $('pType').value,
      price: toNum(val('pPrice')),
      quantity: toNum(val('pQty')),
      discountPercent: toNum(val('pDiscount')),
      section: $('pSection').value || '',
      category: $('pCategory').value || '',
      image: val('pImage').trim(),
      description: val('pDesc'),
      colors: currentColors.map(x=>({label:x.label||'', image:x.image||'', price:toNum(x.price), qty:toNum(x.qty)})),
      sizes: currentSizes.map(x=>({size:x.size||'', price:toNum(x.price), qty:toNum(x.qty)})),
      updatedAt: Date.now()
    };
    if(!p.name || !p.sku){ alert('الاسم و SKU مطلوبان'); return; }
    const data = DB.read(DB.KEY_PRODUCTS, []);
    const idx = (Array.isArray(data)?data:[]).findIndex(x => (x.sku||'').toLowerCase()===p.sku.toLowerCase());
    if(idx>=0){ data[idx] = { ...data[idx], ...p, createdAt: data[idx].createdAt || Date.now() }; }
    else { data.push({ ...p, createdAt: Date.now() }); }
    DB.write(DB.KEY_PRODUCTS, data);
    renderList();
    alert('تم حفظ المنتج');
  }

  function renderList(){
    const host = $('adminProducts');
    const data = DB.read(DB.KEY_PRODUCTS, []);
    if(!Array.isArray(data) || !data.length){ host.innerHTML = '<div class="empty">لا توجد منتجات</div>'; return; }
    host.innerHTML = data.slice().sort((a,b)=>(b.updatedAt||b.createdAt||0)-(a.updatedAt||a.createdAt||0)).map(p=>`
      <div class="card" style="display:grid;grid-template-columns:64px 1fr auto;gap:10px;align-items:center">
        <img src="${p.image||''}" style="width:64px;height:64px;object-fit:cover;border-radius:12px;border:1px solid var(--bd);background:#EDECF4">
        <div>
          <div><strong>${p.name||''}</strong> — <span class="pill" style="font-size:12px">SKU: ${p.sku||''}</span></div>
          <div class="muted" style="font-size:12px">${p.type||'simple'} · ${p.section||'-'} / ${p.category||'-'}</div>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn ghost" onclick="AdminUI.edit('${(p.sku||'').replace(/'/g,'&#39;')}')">تعديل</button>
          <button class="btn" onclick="AdminUI.remove('${(p.sku||'').replace(/'/g,'&#39;')}')">حذف</button>
        </div>
      </div>
    `).join('');
  }

  function edit(sku){
    const data = DB.read(DB.KEY_PRODUCTS, []);
    const p = (Array.isArray(data)?data:[]).find(x => (x.sku||'').toLowerCase()===sku.toLowerCase());
    if(!p) return;
    $('pName').value = p.name||'';
    $('pSku').value = p.sku||'';
    $('pType').value = p.type||'simple';
    $('pPrice').value = p.price||0;
    $('pQty').value = p.quantity||p.qty||0;
    $('pDiscount').value = p.discountPercent||0;
    populateTaxonomySelects();
    $('pSection').value = p.section||'';
    const cats = DB.listCategories(p.section||'');
    $('pCategory').innerHTML = cats.map(c=>`<option value="${c}">${c}</option>`).join('');
    $('pCategory').value = p.category||'';
    $('pImage').value = p.image||'';
    $('pDesc').value = p.description||'';
    currentColors = Array.isArray(p.colors)?p.colors.slice():[];
    currentSizes  = Array.isArray(p.sizes)?p.sizes.slice():[];
    toggleVariantBlocks();
    renderVariants();
    showTab('products');
  }

  function remove(sku){
    if(!confirm('حذف المنتج نهائيًا؟')) return;
    const data = DB.read(DB.KEY_PRODUCTS, []);
    const next = (Array.isArray(data)?data:[]).filter(x => (x.sku||'').toLowerCase()!==sku.toLowerCase());
    DB.write(DB.KEY_PRODUCTS, next);
    renderList();
  }

  // ---------- Cancel with modal ----------
  function showCancel(){
    $('cancelBackdrop').setAttribute('aria-hidden','false');
  }
  function hideCancel(){
    $('cancelBackdrop').setAttribute('aria-hidden','true');
  }
  function confirmCancel(){
    hideCancel();
    resetForm();
  }

  // ---------- Taxonomy (Categories Tab) ----------
  function renderTaxonomy(){
    const host = $('taxList');
    const t = DB.loadTaxonomy();
    if(!(t.sections||[]).length){ host.innerHTML = '<div class="empty">لا توجد أقسام — أضف قسمًا جديدًا</div>'; return; }
    host.innerHTML = (t.sections||[]).map(s=>`
      <div class="card" style="padding:10px">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <strong>${s.name}</strong>
          <div style="display:flex;gap:6px">
            <button class="btn xs ghost" onclick="AdminUI.renameSection('${s.name}')">إعادة تسمية</button>
            <button class="btn xs" onclick="AdminUI.deleteSection('${s.name}')">حذف القسم</button>
          </div>
        </div>
        ${(s.categories||[]).length?`<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
          ${(s.categories||[]).map(c=>`<span class="pill">${c} <a href='#' onclick='AdminUI.deleteCategory("${s.name}","${c}");return false;' style="margin-inline-start:6px;color:#ef4444">حذف</a></span>`).join('')}
        </div>`:'<div class="muted" style="margin-top:6px">لا توجد فئات بعد</div>'}
      </div>
    `).join('');
    const secForCat = $('secForCat');
    secForCat.innerHTML = (t.sections||[]).map(s=>`<option value="${s.name}">${s.name}</option>`).join('');
  }
  function addSection(){
    const name = ($('secName').value||'').trim();
    if(!name){ alert('اكتب اسم القسم'); return; }
    const t = DB.loadTaxonomy();
    if((t.sections||[]).some(s=>s.name===name)){ alert('القسم موجود مسبقًا'); return; }
    t.sections = t.sections || [];
    t.sections.push({ name, categories: [] });
    DB.saveTaxonomy(t);
    $('secName').value='';
    renderTaxonomy();
    populateTaxonomySelects();
  }
  function addCategory(){
    const sec = $('secForCat').value;
    const cat = ($('catName').value||'').trim();
    if(!sec){ alert('اختر القسم'); return; }
    if(!cat){ alert('اكتب اسم الفئة'); return; }
    const t = DB.loadTaxonomy();
    const s = (t.sections||[]).find(x=>x.name===sec);
    if(!s){ alert('القسم غير موجود'); return; }
    s.categories = s.categories || [];
    if(s.categories.includes(cat)){ alert('الفئة موجودة مسبقًا'); return; }
    s.categories.push(cat);
    DB.saveTaxonomy(t);
    $('catName').value='';
    renderTaxonomy();
    populateTaxonomySelects();
  }
  function deleteSection(name){
    if(!confirm('حذف القسم وجميع فئاته؟')) return;
    const t = DB.loadTaxonomy();
    t.sections = (t.sections||[]).filter(s=>s.name!==name);
    DB.saveTaxonomy(t);
    renderTaxonomy();
    populateTaxonomySelects();
  }
  function renameSection(oldName){
    const nn = prompt('اسم القسم الجديد:', oldName)||'';
    const name = nn.trim();
    if(!name) return;
    const t = DB.loadTaxonomy();
    const s = (t.sections||[]).find(x=>x.name===oldName);
    if(!s) return;
    s.name = name;
    DB.saveTaxonomy(t);
    renderTaxonomy();
    populateTaxonomySelects();
  }
  function deleteCategory(sec, cat){
    if(!confirm('حذف هذه الفئة؟')) return;
    const t = DB.loadTaxonomy();
    const s = (t.sections||[]).find(x=>x.name===sec);
    if(!s) return;
    s.categories = (s.categories||[]).filter(c=>c!==cat);
    DB.saveTaxonomy(t);
    renderTaxonomy();
    populateTaxonomySelects();
  }

  // ---------- Settings ----------
  function loadSettings(){
    const v = Settings.load();
    $('sPublic').value  = v.thawani_public_key || '';
    $('sSecret').value  = v.thawani_secret_key || '';
    $('sWebhook').value = v.webhook_secret || '';
    $('sCurrency').value= v.currency || 'OMR';
    $('sShip').value    = v.shipping_flat || '';
    $('sTax').value     = v.tax_percent || '';
  }
  function saveSettings(){
    const v = {
      thawani_public_key: val('sPublic').trim(),
      thawani_secret_key: val('sSecret').trim(),
      webhook_secret: val('sWebhook').trim(),
      currency: val('sCurrency').trim() || 'OMR',
      shipping_flat: Number(val('sShip')||0),
      tax_percent: Number(val('sTax')||0),
    };
    window.BHSettings.save(v);
    alert('تم حفظ الإعدادات');
  }

  // ---------- Wire ----------
  function wire(){
    $('tabBtnProducts').onclick = ()=>showTab('products');
    $('tabBtnCategories').onclick = ()=>showTab('categories');
    $('tabBtnSettings').onclick = ()=>showTab('settings');

    $('pType').onchange = toggleVariantBlocks;
    $('btnSaveProduct').onclick = saveProduct;
    $('btnResetForm').onclick = resetForm;
    $('btnCancelProduct').onclick = showCancel;
    $('addColor').onclick = addColor;
    $('addSize').onclick = addSize;

    $('btnSaveSettings').onclick = saveSettings;
    $('btnLoadSettings').onclick = loadSettings;
  }

  // Expose for inline handlers used in render html strings
  window.AdminUI = {
    showTab, resetForm, saveProduct, renderList, edit, remove,
    addColor, addSize, removeColor, removeSize, onColorField, onSizeField,
    // cancel modal
    showCancel, hideCancel, confirmCancel,
    // taxonomy
    renameSection, deleteSection, deleteCategory
  };

  document.addEventListener('DOMContentLoaded', function(){
    wire();
    showTab('products');
    // Seed taxonomy if empty
    const t = DB.loadTaxonomy();
    if(!(t.sections||[]).length){
      DB.saveTaxonomy({ sections:[ {name:'ملابس', categories:['أطفال','رضّع']}, {name:'إكسسوارات', categories:['مناشف','قبعات']} ] });
    }
    renderList();
    loadSettings();
    populateTaxonomySelects();
    renderTaxonomy();
    toggleVariantBlocks();
    renderVariants();
  });
})();
