/* =======================================================
📁 File: assets/js/products.js (Part 1/6)
🧊 التهيئة + عرض البطاقات + البحث/الفلاتر/الترتيب
======================================================= */

(function () {
  "use strict";

  const { $, $$, fmt } = window.BH;
  const { KEYS, read } = window.DB;

  // حالة واجهة التبويب
  const State = {
    q: "",          // نص البحث
    type: "all",    // نوع المنتج: all | simple | multi-color | multi-size
    stock: "all",   // حالة المخزون: all | ok | warn | alert
    sort: "none",   // ترتيب: none | qty-desc | qty-asc
  };

  // ====== أدوات مساعدة لحساب الكمية والحالة ======
  const toNum = (x) => (isNaN(+x) ? 0 : +x);

  function qtyOf(p) {
    if (p.type === "simple") return toNum(p.qty);
    const key = p.type === "multi-color" ? "colors" : "sizes";
    return (p[key] || []).reduce((sum, v) => sum + toNum(v.qty), 0);
  }

  function badgeClass(q) {
    if (q >= 10) return "ok";
    if (q >= 3) return "warn";
    return "alert";
  }

  function cover(p) {
    if (p.type === "simple") return p.image || "";
    if (p.type === "multi-color") {
      const first = (p.colors || [])[0];
      return first && first.image ? first.image : "";
    }
    return "";
  }

  // ====== البناء المرئي لبطاقة المنتج ======
  function cardHTML(p) {
    const q = qtyOf(p);
    const cls = "qtypill-block " + badgeClass(q);
    const img = cover(p);
    const title = (p.name || p.sku || "").toString();

    return `
    <article class="card" data-sku="${p.sku}">
      <div class="media">
        ${img ? `<img src="${img}" alt="${title}">` : ""}
      </div>
      <div class="info">
        <div class="${cls}">المتبقي: ${q}</div>
        <div class="pname" title="${title}">${title}</div>
        <button class="btn xs ghost" data-act="details">تفاصيل</button>
      </div>
    </article>`;
  }

  // ====== تحميل + تطبيق الفلاتر + العرض ======
  function applyFilters(list) {
    let arr = list.slice();

    // بحث
    if (State.q) {
      const q = State.q.toLowerCase();
      arr = arr.filter(
        (p) =>
          String(p.name || "").toLowerCase().includes(q) ||
          String(p.sku || "").toLowerCase().includes(q) ||
          String(p.type || "").toLowerCase().includes(q)
      );
    }

    // نوع
    if (State.type !== "all") {
      arr = arr.filter((p) => p.type === State.type);
    }

    // حالة المخزون
    if (State.stock !== "all") {
      arr = arr.filter((p) => badgeClass(qtyOf(p)) === State.stock);
    }

    // ترتيب
    if (State.sort === "qty-desc") {
      arr.sort((a, b) => qtyOf(b) - qtyOf(a));
    } else if (State.sort === "qty-asc") {
      arr.sort((a, b) => qtyOf(a) - qtyOf(b));
    }

    return arr;
  }

  function render() {
    const wrap = $("#cards");
    const empty = $("#empty");
    const data = read(KEYS.PRODUCTS, []);
    const list = applyFilters(data);

    if (!list.length) {
      wrap.innerHTML = "";
      empty.hidden = false;
      return;
    }

    empty.hidden = true;
    wrap.innerHTML = list.map(cardHTML).join("");
  }

  // ====== ربط عناصر التحكم (بحث/فلاتر/ترتيب) ======
  function bindControls() {
    $("#q").addEventListener("input", (e) => {
      State.q = (e.target.value || "").trim();
      render();
    });

    $("#fltType").addEventListener("change", (e) => {
      State.type = e.target.value || "all";
      render();
    });

    $("#fltStock").addEventListener("change", (e) => {
      State.stock = e.target.value || "all";
      render();
    });

    $("#sortQty").addEventListener("change", (e) => {
      State.sort = e.target.value || "none";
      render();
    });

    // (سيتم لاحقًا في الأجزاء التالية)
    // - ربط زر "إضافة منتج"
    // - ربط تفاصيل البطاقة
    // - تصدير/استيراد JSON
  }

  // ====== تشغيل التبويب ======
  document.addEventListener("DOMContentLoaded", () => {
    bindControls();
    render();
  });
})();

/* =======================================================
📁 File: assets/js/products.js (Part 2/6)
📝 الإضافة والتعديل: فتح المودال + ملء الحقول + حفظ + إلغاء
======================================================= */

(function () {
  "use strict";

  const { $, $$, toast } = window.BH;
  const { KEYS, read, write } = window.DB;

  // تتبع حالة التعديل داخل المودال
  let editDirty = false;
  const setDirty = () => (editDirty = true);
  const resetDirty = () => (editDirty = false);

  // مراجع عناصر النموذج
  const refs = {
    modal:       () => $("#bd"),
    paneView:    () => $("#pane-view"),
    paneEdit:    () => $("#pane-edit"),
    viewBtns:    () => $("#viewBtns"),
    editBtns:    () => $("#editBtns"),
    ttl:         () => $("#ttl"),

    fmName:      () => $("#fmName"),
    fmSku:       () => $("#fmSku"),
    btnSkuGen:   () => $("#btnSkuGen"),

    fmSection:   () => $("#fmSection"),
    fmCategory:  () => $("#fmCategory"),
    secHint:     () => $("#secHint"),
    catHint:     () => $("#catHint"),

    fmPrice:     () => $("#fmPrice"),
    fmQty:       () => $("#fmQty"),
    fmDesc:      () => $("#fmDesc"),
    fmImage:     () => $("#fmImage"),
    fmPreview:   () => $("#fmPreview"),

    fmMulti:     () => $("#fmMulti"),
    multiCtrls:  () => $("#multiControls"),
    multiColorBox:() => $("#multiColorBox"),
    multiSizeBox: () => $("#multiSizeBox"),
    colorList:   () => $("#colorList"),
    sizeList:    () => $("#sizeList"),

    fmSave:      () => $("#fmSave"),
    btnCancelEdit:() => $("#btnCancelEdit"),
    btnGoEdit:   () => $("#btnGoEdit"),
    btnCloseView:() => $("#btnCloseView"),

    // تأكيد الإلغاء
    bdCancel:    () => $("#bdCancel"),
    btnCancelNo: () => $("#btnCancelNo"),
    btnCancelYes:() => $("#btnCancelYes"),
  };

  // ====== فتح/إغلاق + التبديل بين العرض/التحرير ======
  function openModal() {
    refs.modal().hidden = false;
    document.body.style.overflow = "hidden";
  }
  function closeModal() {
    refs.modal().hidden = true;
    document.body.style.overflow = "";
    resetDirty();
  }
  function switchPane(which) {
    const view = which === "view";
    if (view && !refs.paneEdit().hidden && editDirty) {
      // عند محاولة الرجوع للعرض و في تغييرات غير محفوظة
      refs.bdCancel().hidden = false;
      return;
    }
    refs.paneView().hidden = !view;
    refs.paneEdit().hidden = view;
    refs.viewBtns().hidden = !view;
    refs.editBtns().hidden = view;
    $$(".tabs .tab").forEach((t) =>
      t.classList.toggle("active", t.dataset.pane === which)
    );
    if (view) resetDirty();
  }

  // ====== أدوات الأقسام/الفئات ======
  function sections() {
    return read(KEYS.SECTIONS, []).sort((a, b) =>
      String(a.name).localeCompare(b.name, "ar")
    );
  }
  function categories() {
    return read(KEYS.CATEGORIES, []);
  }
  function populateSectionSelect() {
    const sel = refs.fmSection();
    const hint = refs.secHint();
    const secs = sections();
    if (!secs.length) {
      sel.innerHTML = '<option value="">— لا توجد أقسام —</option>';
      hint.hidden = false;
      return;
    }
    hint.hidden = true;
    sel.innerHTML =
      '<option value="">— اختر القسم —</option>' +
      secs.map((s) => `<option value="${s.id}">${s.name}</option>`).join("");
  }
  function populateCategorySelect(sectionId, presetName) {
    const sel = refs.fmCategory();
    const hint = refs.catHint();
    if (!sectionId) {
      sel.innerHTML = '<option value="">— اختر قسمًا أولًا —</option>';
      hint.hidden = false;
      return;
    }
    const cats = categories()
      .filter((c) => c.sectionId === sectionId)
      .sort((a, b) => String(a.name).localeCompare(b.name, "ar"));

    if (!cats.length) {
      sel.innerHTML = '<option value="">— لا توجد فئات لهذا القسم —</option>';
      hint.hidden = false;
      return;
    }
    hint.hidden = true;
    sel.innerHTML =
      '<option value="">— اختر الفئة —</option>' +
      cats.map((c) => `<option value="${c.id}">${c.name}</option>`).join("");

    // اختيار الفئة المحفوظة إن وُجدت
    if (presetName) {
      const hit = cats.find((c) => String(c.name).trim() === String(presetName).trim());
      if (hit) sel.value = hit.id;
    }
  }
  function resolveNamesFromIds(sectionId, categoryId) {
    const s = sections().find((x) => x.id === sectionId);
    const c = categories().find((x) => x.id === categoryId);
    return { sectionName: s ? s.name : "", categoryName: c ? c.name : "" };
  }

  // ====== قراءة/ملء/تهيئة النموذج ======
  function resetForm() {
    refs.fmName().value = "";
    refs.fmSku().value = "";

    populateSectionSelect();
    refs.fmSection().value = "";
    populateCategorySelect("", "");
    refs.fmCategory().value = "";

    refs.secHint().hidden = sections().length > 0;
    refs.catHint().hidden = true;

    refs.fmPrice().value = "";
    refs.fmQty().value = "";
    refs.fmDesc().value = "";

    refs.fmImage().value = "";
    refs.fmPreview().style.display = "none";
    refs.fmPreview().src = "";

    refs.fmMulti().checked = false;
    refs.multiCtrls().hidden = true;
    $$('#multiControls input[type="radio"]').forEach((r) => (r.checked = false));
    refs.multiColorBox().hidden = true;
    refs.multiSizeBox().hidden = true;
    refs.colorList().innerHTML = "";
    refs.sizeList().innerHTML = "";

    refs.fmSave().dataset.mode = "create";
    refs.fmSave().dataset.sku = "";
    resetDirty();
  }

  function fillForm(p) {
    // الحقول الأساسية
    refs.fmName().value = p.name || "";
    refs.fmSku().value = p.sku || "";
    refs.fmDesc().value = p.desc || "";

    // القسم/الفئة
    populateSectionSelect();
    const secObj = sections().find(
      (s) => String(s.name).trim() === String(p.section || "").trim()
    );
    const secId = secObj ? secObj.id : "";
    refs.fmSection().value = secId || "";
    populateCategorySelect(secId, p.category || "");
    if (p.category && secId) {
      const cats = categories().filter((c) => c.sectionId === secId);
      const ok = cats.some(
        (c) => String(c.name).trim() === String(p.category).trim()
      );
      if (!ok) {
        refs.catHint().hidden = false;
        refs.catHint().textContent = "الفئة المحفوظة لا تنتمي لهذا القسم.";
      }
    }

    // النوع والسعر/الكمية والصورة
    if (p.type === "simple") {
      refs.fmPrice().value = p.price || 0;
      refs.fmQty().value = p.qty || 0;
      if (p.image) {
        refs.fmPreview().src = p.image;
        refs.fmPreview().style.display = "inline-block";
      }
    } else {
      refs.fmPrice().value = "";
      refs.fmQty().value = "";
      refs.fmPreview().style.display = "none";
      refs.fmPreview().src = "";
    }

    // تعدد
    if (p.type === "multi-color" || p.type === "multi-size") {
      refs.fmMulti().checked = true;
      refs.multiCtrls().hidden = false;
      $$('#multiControls input[type="radio"]').forEach((r) => {
        r.checked = r.value === (p.type === "multi-color" ? "color" : "size");
      });
      if (p.type === "multi-color") {
        refs.multiColorBox().hidden = false;
        refs.multiSizeBox().hidden = true;
        refs.colorList().innerHTML = "";
        (p.colors || []).forEach((c) => addColorRow(c.label, c.price, c.qty, c.image));
      } else {
        refs.multiColorBox().hidden = true;
        refs.multiSizeBox().hidden = false;
        refs.sizeList().innerHTML = "";
        (p.sizes || []).forEach((sv) => addSizeRow(sv.size, sv.price, sv.qty));
      }
    } else {
      refs.multiCtrls().hidden = true;
      refs.multiColorBox().hidden = true;
      refs.multiSizeBox().hidden = true;
      refs.colorList().innerHTML = "";
      refs.sizeList().innerHTML = "";
    }

    refs.fmSave().dataset.mode = "update";
    refs.fmSave().dataset.sku = p.sku || "";
    resetDirty();
  }

  function readForm() {
    const sectionId = refs.fmSection().value || "";
    const categoryId = refs.fmCategory().value || "";
    const names = resolveNamesFromIds(sectionId, categoryId);

    const multi = refs.fmMulti().checked;
    let kind = null;
    if (multi) {
      for (const r of $$('#multiControls input[name="multiKind"]')) {
        if (r.checked) { kind = r.value; break; }
      }
    }

    const base = {
      name: (refs.fmName().value || "").trim(),
      sku: (refs.fmSku().value || "").trim(),
      desc: (refs.fmDesc().value || "").trim(),
      section: names.sectionName || "",
      category: names.categoryName || "",
    };

    if (!multi) {
      base.type = "simple";
      base.price = Number(refs.fmPrice().value || 0);
      base.qty = Number(refs.fmQty().value || 0);
      base.image = refs.fmPreview().src || "";
    } else if (kind === "color") {
      base.type = "multi-color";
      base.colors = $$("#colorList .var-row").map((row) => {
        const img = row.querySelector(".v-image-preview");
        return {
          label: (row.querySelector(".v-label").value || "").trim(),
          price: Number(row.querySelector(".v-price").value || 0),
          qty: Number(row.querySelector(".v-qty").value || 0),
          image: img ? img.getAttribute("src") || "" : "",
        };
      });
    } else {
      base.type = "multi-size";
      base.sizes = $$("#sizeList .var-row.size").map((row) => ({
        size: (row.querySelector(".v-size").value || "").trim(),
        price: Number(row.querySelector(".v-price").value || 0),
        qty: Number(row.querySelector(".v-qty").value || 0),
      }));
    }

    return base;
  }

  // ====== توليد SKU ======
  function genSku() {
    const base = ("BH-" + (refs.fmName().value || "ITEM"))
      .toUpperCase()
      .replace(/\s+/g, "-")
      .replace(/[^A-Z0-9\-]/g, "")
      .slice(0, 16);
    const seed = Date.now().toString(36).toUpperCase().slice(-4);
    refs.fmSku().value = `${base}-S-${seed}`;
    setDirty();
    toast("تم توليد SKU");
  }

  // ====== فتح المودال على وضع الإضافة ======
  $("#btnAdd").addEventListener("click", () => {
    refs.ttl().textContent = "إضافة منتج جديد";
    resetForm();
    refs.paneView().hidden = true;
    refs.paneEdit().hidden = false;
    refs.viewBtns().hidden = true;
    refs.editBtns().hidden = false;
    openModal();
  });

  // ====== التبديل بين التفاصيل والتحرير ======
  $$(".tabs .tab").forEach((t) =>
    t.addEventListener("click", () => switchPane(t.dataset.pane))
  );
  refs.btnGoEdit().addEventListener("click", () => switchPane("edit"));
  refs.btnCloseView().addEventListener("click", () => {
    if (!editDirty) return closeModal();
    refs.bdCancel().hidden = false;
  });

  // زر إلغاء أثناء التحرير
  refs.btnCancelEdit().addEventListener("click", () => {
    if (editDirty) refs.bdCancel().hidden = false;
    else switchPane("view");
  });
  refs.btnCancelNo().addEventListener("click", () => (refs.bdCancel().hidden = true));
  refs.btnCancelYes().addEventListener("click", () => {
    refs.bdCancel().hidden = true;
    refs.paneView().hidden = false;
    refs.paneEdit().hidden = true;
    refs.viewBtns().hidden = false;
    refs.editBtns().hidden = true;
    resetDirty();
  });

  // توليد SKU
  refs.btnSkuGen().addEventListener("click", genSku);

  // علامة تعديل على أي إدخال
  refs.paneEdit().addEventListener("input", (e) => {
    if (e.target && e.target.tagName !== "BUTTON") setDirty();
  });

  // معاينة الصورة للنوع البسيط
  refs.fmImage().addEventListener("change", function () {
    const f = this.files && this.files[0];
    if (!f) {
      refs.fmPreview().style.display = "none";
      refs.fmPreview().src = "";
      return;
    }
    const fr = new FileReader();
    fr.onload = (e) => {
      refs.fmPreview().src = String(e.target.result || "");
      refs.fmPreview().style.display = "inline-block";
      setDirty();
    };
    fr.readAsDataURL(f);
  });

  // ربط القسم ← الفئات
  refs.fmSection().addEventListener("change", function () {
    populateCategorySelect(this.value || "", "");
    setDirty();
  });

  // حفظ (إنشاء/تحديث) — سيتم التحقق الإضافي وإكماله في الجزء 6
  refs.fmSave().addEventListener("click", () => {
    const mode = refs.fmSave().dataset.mode || "create";
    const originalSku = (refs.fmSave().dataset.sku || "").toLowerCase();
    const item = readForm();

    if (!item.name || !item.sku) return toast("الاسم و كود المنتج مطلوبان");
    if (!item.section) return toast("اختر قسمًا");

    // تحقق ازدواجية SKU
    const all = read(KEYS.PRODUCTS, []);
    const dup = all.some(
      (p) =>
        String(p.sku || "").toLowerCase() === String(item.sku || "").toLowerCase() &&
        (mode === "create" || (mode === "update" && item.sku.toLowerCase() !== originalSku))
    );
    if (dup) return toast("SKU مستخدم مسبقًا");

    // تحقق أساسي حسب النوع
    if (item.type === "simple" && Number(item.price) <= 0) {
      return toast("أدخل سعرًا صالحًا");
    }

    // حفظ فعلي
    const idx = all.findIndex((p) => String(p.sku || "").toLowerCase() === originalSku);
    if (idx >= 0) all[idx] = item;
    else all.unshift(item);

    write(KEYS.PRODUCTS, all);
    toast("تم الحفظ");

    // بعد الحفظ سنملأ النموذج ونعرض التفاصيل (يُستكمل في الأجزاء التالية)
    refs.fmSave().dataset.mode = "update";
    refs.fmSave().dataset.sku = item.sku || "";
    switchPane("view");
  });

  // إتاحة دوال يحتاجها الجزء 3/4 لاحقًا
  window.__BH_products_part2__ = { openModal, closeModal, switchPane, fillForm, resetForm, populateSectionSelect, populateCategorySelect, resolveNamesFromIds, setDirty, resetDirty };
})();


/* =======================================================
📁 File: assets/js/products.js (Part 3/6)
🗑️ الحذف + تأكيدات + نسخ SKU + فتح تفاصيل من البطاقة
======================================================= */

(function () {
  "use strict";

  const { $, $$, toast } = window.BH;
  const { KEYS, read, write } = window.DB;

  // من الجزء السابق:
  const ref = window.__BH_products_part2__;
  const openModal = ref.openModal;
  const closeModal = ref.closeModal;
  const switchPane = ref.switchPane;
  const fillForm  = ref.fillForm;
  const resetForm = ref.resetForm;

  // ========= بناء تفاصيل العرض =========
  function toNum(x){ const n=Number(x); return isNaN(n)?0:n; }
  function qtyOf(p){
    if(p.type==='simple') return toNum(p.qty);
    const key = (p.type==='multi-color')?'colors':'sizes';
    return (p[key]||[]).reduce((a,v)=> a+toNum(v.qty), 0);
  }
  function renderDesc(desc){
    const s=(desc||"").trim(); if(!s) return "";
    const lines=s.split(/\r?\n/);
    const allBullets = lines.every(l=>/^\s*[-•]/.test(l));
    if(allBullets){
      const lis = lines.map(l=>"<li>"+l.replace(/^\s*[-•]\s?/, "")+"</li>").join("");
      return `<ul style="margin:6px 0;padding-inline-start:18px">${lis}</ul>`;
    }
    return `<p class="muted" style="margin:6px 0">${s.replace(/\n/g,"<br>")}</p>`;
  }
  function detailsHTML(p){
    let html = `<div class="row">
      <div><b>الاسم:</b> ${p.name||""}</div>
      <div><b>SKU:</b> <code class="sku">${p.sku||""}</code>
        <button class="btn xs ghost" data-act="copy-sku" data-sku="${p.sku||""}">نسخ</button>
      </div>
      <div><b>النوع:</b> ${p.type==='simple'?'عادي':(p.type==='multi-color'?'متعدد (ألوان)':'متعدد (أحجام)')}</div>
      <div><b>القسم:</b> ${p.section||"-"}</div>
      <div><b>الفئة:</b> ${p.category||"-"}</div>
      <div><b>المتبقي:</b> ${qtyOf(p)}</div>
      ${p.type==='simple'?`<div><b>السعر:</b> ${(Number(p.price)||0).toFixed(3)} ر.ع</div>`:""}
    </div>`;
    html += renderDesc(p.desc||"");
    if(p.type==='multi-color'){
      html += `<table><thead><tr><th>اللون</th><th>الصورة</th><th>السعر</th><th>الكمية</th></tr></thead><tbody>`;
      (p.colors||[]).forEach(c=>{
        html += `<tr>
          <td>${c.label||""}</td>
          <td>${c.image?`<img src="${c.image}" class="thumb-sm">`:"—"}</td>
          <td>${(Number(c.price)||0).toFixed(3)} ر.ع</td>
          <td>${toNum(c.qty)}</td>
        </tr>`;
      });
      html += `</tbody></table>`;
    } else if(p.type==='multi-size'){
      html += `<table><thead><tr><th>الحجم</th><th>السعر</th><th>الكمية</th></tr></thead><tbody>`;
      (p.sizes||[]).forEach(sv=>{
        html += `<tr>
          <td>${sv.size||""}</td>
          <td>${(Number(sv.price)||0).toFixed(3)} ر.ع</td>
          <td>${toNum(sv.qty)}</td>
        </tr>`;
      });
      html += `</tbody></table>`;
    }
    return html;
  }

  // ========= فتح تفاصيل من البطاقة =========
  $("#cards").addEventListener("click", (e)=>{
    const btn = e.target.closest('[data-act="details"]');
    if(!btn) return;
    const card = btn.closest(".card");
    const sku = card?.getAttribute("data-sku");
    const item = read(KEYS.PRODUCTS, []).find(p => String(p.sku).toLowerCase()===String(sku).toLowerCase());
    if(!item) return toast("العنصر غير موجود");

    $("#ttl").textContent = "تفاصيل المنتج — " + (item.name||item.sku);
    $("#pane-view").innerHTML = detailsHTML(item);
    fillForm(item); // يجهز نموذج التحرير لنفس العنصر
    $("#pane-view").hidden = false;
    $("#pane-edit").hidden = true;
    $("#viewBtns").hidden = false;
    $("#editBtns").hidden = true;
    openModal();
  });

  // ========= الحذف + التأكيد + النسخ =========
  // فتح مودال الحذف من داخل مودال المنتج
  $("#btnDelete").addEventListener("click", ()=>{
    const sku = ($("#fmSave").dataset.sku||"").trim();
    if(!sku) return toast("لا يوجد عنصر محدد");
    const list = read(KEYS.PRODUCTS, []);
    const item = list.find(p => String(p.sku||"").toLowerCase()===sku.toLowerCase());
    if(!item) return toast("العنصر غير موجود");
    $("#delName").textContent = item.name||item.sku||"—";
    $("#delSku").textContent  = item.sku||"";
    $("#bdDel").hidden = false;
  });

  // إلغاء الحذف
  $("#btnDelCancel").addEventListener("click", ()=> $("#bdDel").hidden = true);

  // تأكيد الحذف
  $("#btnDelConfirm").addEventListener("click", ()=>{
    const sku = $("#delSku").textContent||"";
    const left = read(KEYS.PRODUCTS, []).filter(p => String(p.sku).toLowerCase() !== String(sku).toLowerCase());
    write(KEYS.PRODUCTS, left);
    $("#bdDel").hidden = true;
    closeModal(); // إغلاق تفاصيل المنتج
    toast("تم حذف المنتج");
    // إعادة بناء الشبكة
    const evt = new Event("input"); // حيلة بسيطة لإعادة الريندر عبر الفلاتر الحالية
    ($("#q")||document.body).dispatchEvent(evt);
    // أو يمكنك مباشرةً إعادة تحميل عبر استدعاء نفس منطق العرض في الجزء 1 إن كنت قد فصلته لدالة عامة
    // هنا سنُعيد تحميل بسيط:
    setTimeout(()=> {
      const data = read(KEYS.PRODUCTS, []);
      const wrap = $("#cards"), empty=$("#empty");
      if(!data.length){ wrap.innerHTML=""; empty.hidden=false; }
      else {
        // سنعتمد على حدث البحث الذي يعيد الاستدعاء — أو اتركه كما هو لأن الفلاتر ترتبط بالأحداث
        // للتبسيط نطلق تغيير مصطنع على ترتيب الكمية:
        const s = $("#sortQty"); if(s){ const v=s.value; s.value=v; s.dispatchEvent(new Event("change")); }
      }
    }, 50);
  });

  // نسخ SKU
  $("#btnCopySku").addEventListener("click", ()=>{
    const sku = $("#delSku").textContent||"";
    if(navigator.clipboard && sku){
      navigator.clipboard.writeText(sku).then(()=> toast("تم نسخ SKU"));
    }
  });

  // نسخ SKU من شاشة التفاصيل
  $("#pane-view").addEventListener("click", (e)=>{
    const b = e.target.closest('[data-act="copy-sku"]');
    if(!b) return;
    const v = b.dataset.sku||"";
    if(navigator.clipboard && v){
      navigator.clipboard.writeText(v).then(()=> toast("تم نسخ SKU"));
    }
  });

})();


/* =======================================================
📁 File: assets/js/products.js (Part 4/6)
🎨 تعدد الألوان والأحجام (Variants) + أزرار الحذف + المعاينات
======================================================= */

(function () {
  "use strict";

  const { $, $$, toast } = window.BH;

  // من الجزء 2:
  const ref = window.__BH_products_part2__;
  const setDirty  = ref.setDirty;
  const resetDirty= ref.resetDirty;

  // ====== إنشاء صف لون ======
  function addColorRow(label = "", price = 0, qty = 0, imageDataURL = "") {
    const row = document.createElement("div");
    row.className = "var-row";

    row.innerHTML = `
      <div class="field">
        <span class="l">اللون</span>
        <input class="v-label" placeholder="اسم اللون" value="${label}">
      </div>

      <div class="field">
        <span class="l">السعر (ر.ع)</span>
        <input class="v-price" type="number" step="0.001" placeholder="0.000" value="${price}">
      </div>

      <div class="field">
        <span class="l">الكمية</span>
        <input class="v-qty" type="number" step="1" placeholder="0" value="${qty}">
      </div>

      <div class="field">
        <span class="l">الصورة</span>
        <div class="inline">
          <input class="v-image" type="file" accept="image/*">
          <img class="v-image-preview thumb-sm" ${imageDataURL ? `src="${imageDataURL}"` : 'style="display:none"'} />
          <button class="btn xs danger v-del" type="button" title="حذف هذا اللون">حذف</button>
        </div>
      </div>
    `;

    // رفع صورة اللون + المعاينة
    const fileInp = row.querySelector(".v-image");
    const prev    = row.querySelector(".v-image-preview");
    fileInp.addEventListener("change", function () {
      const f = this.files && this.files[0];
      if (!f) { prev.style.display = "none"; prev.src = ""; return; }
      const fr = new FileReader();
      fr.onload = (e) => {
        prev.src = String(e.target.result || "");
        prev.style.display = "inline-block";
        setDirty();
      };
      fr.readAsDataURL(f);
    });

    // حذف صف اللون (زر بجانب الصورة)
    row.querySelector(".v-del").addEventListener("click", () => {
      row.remove();
      setDirty();
    });

    // أي تغيير في الحقول يوسّخ النموذج
    row.addEventListener("input", (e) => {
      if (e.target && e.target.tagName !== "BUTTON") setDirty();
    });

    $("#colorList").appendChild(row);
  }

  // ====== إنشاء صف حجم ======
  function addSizeRow(size = "", price = 0, qty = 0) {
    const row = document.createElement("div");
    row.className = "var-row size";

    row.innerHTML = `
      <div class="field">
        <span class="l">الحجم</span>
        <input class="v-size" placeholder="S / M / L…" value="${size}">
      </div>

      <div class="field">
        <span class="l">السعر (ر.ع)</span>
        <input class="v-price" type="number" step="0.001" placeholder="0.000" value="${price}">
      </div>

      <div class="field">
        <span class="l">الكمية</span>
        <input class="v-qty" type="number" step="1" placeholder="0" value="${qty}">
      </div>

      <div style="display:flex;align-items:flex-end">
        <button class="btn xs danger" type="button" title="حذف هذا الحجم">حذف</button>
      </div>
    `;

    // حذف صف الحجم (زر في نهاية الصف)
    row.querySelector("button").addEventListener("click", () => {
      row.remove();
      setDirty();
    });

    // أي تغيير في الحقول يوسّخ النموذج
    row.addEventListener("input", (e) => {
      if (e.target && e.target.tagName !== "BUTTON") setDirty();
    });

    $("#sizeList").appendChild(row);
  }

  // ====== ربط الأزرار وتبديل الأنواع ======
  document.addEventListener("DOMContentLoaded", () => {
    // إضافة صف لون/حجم
    $("#btnColorAdd").addEventListener("click", () => {
      addColorRow("", 0, 0, "");
      setDirty();
    });
    $("#btnSizeAdd").addEventListener("click", () => {
      addSizeRow("", 0, 0);
      setDirty();
    });

    // تفعيل/إلغاء تعدد الأنواع
    $("#fmMulti").addEventListener("change", function () {
      const on = this.checked;
      $("#multiControls").hidden = !on;
      if (!on) {
        // إخفاء الكتل وإلغاء اختيار الراديو
        $("#multiColorBox").hidden = true;
        $("#multiSizeBox").hidden = true;
        $$('#multiControls input[type="radio"]').forEach((r) => (r.checked = false));
      }
      setDirty();
    });

    // اختيار النوع: ألوان أو أحجام
    $$('#multiControls input[type="radio"]').forEach((r) =>
      r.addEventListener("change", function () {
        if (this.value === "color") {
          $("#multiColorBox").hidden = false;
          $("#multiSizeBox").hidden = true;
        } else {
          $("#multiColorBox").hidden = true;
          $("#multiSizeBox").hidden = false;
        }
        setDirty();
      })
    );
  });

  // إتاحة الدوال للأجزاء الأخرى (الحفظ يقرأ منها في Part 2)
  window.__BH_products_part4__ = { addColorRow, addSizeRow };
})();


/* =======================================================
📁 File: assets/js/products.js (Part 5/6)
⬇️⬆️ تصدير/استيراد JSON للمنتجات + تحقق بنيوي
======================================================= */

(function () {
  "use strict";

  const { $, toast } = window.BH;
  const { KEYS, read, write } = window.DB;

  // ====== مصادقة بنية المنتج بشكل مبسّط ======
  function isValidProduct(p) {
    if (!p || typeof p !== "object") return false;
    if (!p.name || !p.sku || !p.type) return false;

    // نوع بسيط
    if (p.type === "simple") {
      if (typeof p.price !== "number") return false;
      if (typeof p.qty !== "number") return false;
      return true;
    }

    // متعدد الألوان
    if (p.type === "multi-color") {
      if (!Array.isArray(p.colors) || p.colors.length < 1) return false;
      return p.colors.every(
        (c) =>
          c &&
          typeof c === "object" &&
          typeof c.label === "string" &&
          typeof c.price === "number" &&
          typeof c.qty === "number"
      );
    }

    // متعدد الأحجام
    if (p.type === "multi-size") {
      if (!Array.isArray(p.sizes) || p.sizes.length < 1) return false;
      return p.sizes.every(
        (s) =>
          s &&
          typeof s === "object" &&
          typeof s.size === "string" &&
          typeof s.price === "number" &&
          typeof s.qty === "number"
      );
    }

    return false;
  }

  // ====== تصدير JSON ======
  $("#btnExport").addEventListener("click", () => {
    const data = read(KEYS.PRODUCTS, []);
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "products-export.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 0);
    toast("تم تصدير JSON");
  });

  // ====== استيراد JSON ======
  $("#btnImport").addEventListener("click", () => $("#fileImport").click());

  $("#fileImport").addEventListener("change", function () {
    const f = this.files && this.files[0];
    if (!f) return;

    const fr = new FileReader();
    fr.onload = (e) => {
      try {
        const obj = JSON.parse(String(e.target.result || "[]"));
        if (!Array.isArray(obj)) throw new Error("الملف ليس مصفوفة منتجات");

        // تحقق من البنية وتفادي تكرار SKU
        const incoming = obj.filter(isValidProduct);
        if (!incoming.length) throw new Error("لا توجد عناصر صالحة للاستيراد");

        const existing = read(KEYS.PRODUCTS, []);
        const bySku = new Map(
          existing.map((p) => [String(p.sku).toLowerCase(), p])
        );

        for (const item of incoming) {
          const k = String(item.sku).toLowerCase();
          bySku.set(k, item); // إدراج/استبدال (Merge by SKU)
        }

        const merged = Array.from(bySku.values());
        write(KEYS.PRODUCTS, merged);
        toast(`تم الاستيراد (${incoming.length}) عنصرًا. الإجمالي الآن: ${merged.length}.`);

        // إعادة البناء عبر إطلاق حدث تغيير بسيط على الفلاتر
        const s = $("#sortQty");
        if (s) {
          const v = s.value;
          s.value = v;
          s.dispatchEvent(new Event("change"));
        }
      } catch (err) {
        console.error(err);
        toast("فشل الاستيراد: تحقق من صيغة الملف");
      } finally {
        this.value = "";
      }
    };
    fr.readAsText(f);
  });
})();


/* =======================================================
📁 File: assets/js/products.js (Part 6/6)
🔗 ربط الأقسام/الفئات + تحقق نهائي عند الحفظ + تحديث التفاصيل
+ جسر إصلاح استدعاء addColorRow/addSizeRow داخل fillForm
======================================================= */

(function () {
  "use strict";

  const { $, $$, toast } = window.BH;
  const { KEYS, read, write } = window.DB;

  // ============== جسر إصلاح fillForm (Part2 ← Part4) ==============
  // نجعل fillForm تستخدم دوال Part4 المعرّفة داخل نافذة عامة
  const P2 = window.__BH_products_part2__;
  const P4 = window.__BH_products_part4__;
  if (P2 && P4) {
    P2.fillForm = function fillFormPatched(p) {
      // نفس منطق Part2 ولكن يستدعي P4.addColorRow / P4.addSizeRow
      const secs = read(KEYS.SECTIONS, []).sort((a, b) => String(a.name).localeCompare(b.name, "ar"));
      const cats = read(KEYS.CATEGORIES, []);

      // تعبئة الحقول الأساسية
      $("#fmName").value = p.name || "";
      $("#fmSku").value = p.sku || "";
      $("#fmDesc").value = p.desc || "";

      // الأقسام
      const secSel = $("#fmSection");
      const secHint = $("#secHint");
      if (!secs.length) {
        secSel.innerHTML = '<option value="">— لا توجد أقسام —</option>';
        secHint.hidden = false;
      } else {
        secHint.hidden = true;
        secSel.innerHTML = '<option value="">— اختر القسم —</option>' + secs.map(s => `<option value="${s.id}">${s.name}</option>`).join("");
      }
      const secObj = secs.find(s => String(s.name).trim() === String(p.section || "").trim());
      const secId = secObj ? secObj.id : "";
      secSel.value = secId || "";

      // الفئات
      const catSel = $("#fmCategory");
      const catHint = $("#catHint");
      if (!secId) {
        catSel.innerHTML = '<option value="">— اختر قسمًا أولًا —</option>';
        catHint.hidden = false;
      } else {
        const relatedCats = cats.filter(c => c.sectionId === secId).sort((a, b) => String(a.name).localeCompare(b.name, "ar"));
        if (!relatedCats.length) {
          catSel.innerHTML = '<option value="">— لا توجد فئات لهذا القسم —</option>';
          catHint.hidden = false;
        } else {
          catHint.hidden = true;
          catSel.innerHTML = '<option value="">— اختر الفئة —</option>' + relatedCats.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
          if (p.category) {
            const hit = relatedCats.find(c => String(c.name).trim() === String(p.category).trim());
            if (hit) catSel.value = hit.id;
            else { catHint.hidden = false; catHint.textContent = "الفئة المحفوظة لا تنتمي لهذا القسم."; }
          }
        }
      }

      // النوع والسعر/الكمية والصورة
      if (p.type === "simple") {
        $("#fmPrice").value = p.price || 0;
        $("#fmQty").value = p.qty || 0;
        if (p.image) {
          $("#fmPreview").src = p.image;
          $("#fmPreview").style.display = "inline-block";
        } else {
          $("#fmPreview").style.display = "none";
          $("#fmPreview").src = "";
        }
      } else {
        $("#fmPrice").value = "";
        $("#fmQty").value = "";
        $("#fmPreview").style.display = "none";
        $("#fmPreview").src = "";
      }

      // تعدد
      $("#fmMulti").checked = (p.type === "multi-color" || p.type === "multi-size");
      $("#multiControls").hidden = !$("#fmMulti").checked;
      $$('#multiControls input[type="radio"]').forEach(r => r.checked = false);
      $("#multiColorBox").hidden = true;
      $("#multiSizeBox").hidden = true;
      $("#colorList").innerHTML = "";
      $("#sizeList").innerHTML = "";

      if (p.type === "multi-color") {
        $$('#multiControls input[type="radio"]').forEach(r => r.checked = (r.value === "color"));
        $("#multiColorBox").hidden = false;
        (p.colors || []).forEach(c => P4.addColorRow(c.label || "", c.price || 0, c.qty || 0, c.image || ""));
      } else if (p.type === "multi-size") {
        $$('#multiControls input[type="radio"]').forEach(r => r.checked = (r.value === "size"));
        $("#multiSizeBox").hidden = false;
        (p.sizes || []).forEach(sv => P4.addSizeRow(sv.size || "", sv.price || 0, sv.qty || 0));
      }

      $("#fmSave").dataset.mode = "update";
      $("#fmSave").dataset.sku = p.sku || "";
    };
  }

  // ============== أدوات مساعدة مشتركة ==============
  function toNum(x){ const n=Number(x); return isNaN(n)?0:n; }
  function qtyOf(p){
    if(p.type==='simple') return toNum(p.qty);
    const key = (p.type==='multi-color')?'colors':'sizes';
    return (p[key]||[]).reduce((a,v)=> a+toNum(v.qty), 0);
  }
  function detailsHTML(p){
    let html = `<div class="row">
      <div><b>الاسم:</b> ${p.name||""}</div>
      <div><b>SKU:</b> <code class="sku">${p.sku||""}</code>
        <button class="btn xs ghost" data-act="copy-sku" data-sku="${p.sku||""}">نسخ</button>
      </div>
      <div><b>النوع:</b> ${p.type==='simple'?'عادي':(p.type==='multi-color'?'متعدد (ألوان)':'متعدد (أحجام)')}</div>
      <div><b>القسم:</b> ${p.section||"-"}</div>
      <div><b>الفئة:</b> ${p.category||"-"}</div>
      <div><b>المتبقي:</b> ${qtyOf(p)}</div>
      ${p.type==='simple'?`<div><b>السعر:</b> ${(Number(p.price)||0).toFixed(3)} ر.ع</div>`:""}
    </div>`;

    // وصف
    const s = String(p.desc||"").trim();
    if (s) {
      const lines = s.split(/\r?\n/);
      const allBullets = lines.every(l => /^\s*[-•]/.test(l));
      if (allBullets) {
        const lis = lines.map(l => "<li>"+l.replace(/^\s*[-•]\s?/, "")+"</li>").join("");
        html += `<ul style="margin:6px 0;padding-inline-start:18px">${lis}</ul>`;
      } else {
        html += `<p class="muted" style="margin:6px 0">${s.replace(/\n/g,"<br>")}</p>`;
      }
    }

    // جداول المتغيرات
    if(p.type==='multi-color'){
      html += `<table><thead><tr><th>اللون</th><th>الصورة</th><th>السعر</th><th>الكمية</th></tr></thead><tbody>`;
      (p.colors||[]).forEach(c=>{
        html += `<tr>
          <td>${c.label||""}</td>
          <td>${c.image?`<img src="${c.image}" class="thumb-sm">`:"—"}</td>
          <td>${(Number(c.price)||0).toFixed(3)} ر.ع</td>
          <td>${toNum(c.qty)}</td>
        </tr>`;
      });
      html += `</tbody></table>`;
    } else if(p.type==='multi-size'){
      html += `<table><thead><tr><th>الحجم</th><th>السعر</th><th>الكمية</th></tr></thead><tbody>`;
      (p.sizes||[]).forEach(sv=>{
        html += `<tr>
          <td>${sv.size||""}</td>
          <td>${(Number(sv.price)||0).toFixed(3)} ر.ع</td>
          <td>${toNum(sv.qty)}</td>
        </tr>`;
      });
      html += `</tbody></table>`;
    }
    return html;
  }

  // ============== قراءة النموذج (نسخة مستقلة للحفظ المعزّز) ==============
  function sections(){ return read(KEYS.SECTIONS, []).sort((a,b)=> String(a.name).localeCompare(b.name,"ar")); }
  function categories(){ return read(KEYS.CATEGORIES, []); }
  function resolveNamesFromIds(sectionId, categoryId){
    const s = sections().find(x=> x.id===sectionId);
    const c = categories().find(x=> x.id===categoryId);
    return { sectionName: s? s.name:"", categoryName: c? c.name:"" };
  }
  function readFormEnhanced(){
    const sectionId = $("#fmSection").value || "";
    const categoryId = $("#fmCategory").value || "";
    const names = resolveNamesFromIds(sectionId, categoryId);

    const multi = $("#fmMulti").checked;
    let kind = null;
    if (multi) {
      for (const r of $$('#multiControls input[name="multiKind"]')) { if (r.checked){ kind = r.value; break; } }
    }

    const base = {
      name: ($("#fmName").value||"").trim(),
      sku: ($("#fmSku").value||"").trim(),
      desc: ($("#fmDesc").value||"").trim(),
      section: names.sectionName || "",
      category: names.categoryName || "",
    };

    if (!multi){
      base.type = "simple";
      base.price = Number($("#fmPrice").value||0);
      base.qty   = Number($("#fmQty").value||0);
      base.image = $("#fmPreview").src || "";
    } else if (kind === "color"){
      base.type = "multi-color";
      base.colors = $$("#colorList .var-row").map(row=>{
        const img = row.querySelector(".v-image-preview");
        return {
          label: (row.querySelector(".v-label").value||"").trim(),
          price: Number(row.querySelector(".v-price").value||0),
          qty:   Number(row.querySelector(".v-qty").value||0),
          image: img ? (img.getAttribute("src")||"") : "",
        };
      });
    } else {
      base.type = "multi-size";
      base.sizes = $$("#sizeList .var-row.size").map(row=>({
        size:  (row.querySelector(".v-size").value||"").trim(),
        price: Number(row.querySelector(".v-price").value||0),
        qty:   Number(row.querySelector(".v-qty").value||0),
      }));
    }

    return base;
  }

  // ============== تعزيز الحفظ ومنع تعارض المستمع السابق ==============
  function enhancedSave(){
    const mode = $("#fmSave").dataset.mode || "create";
    const originalSku = ( $("#fmSave").dataset.sku || "" ).toLowerCase();
    const item = readFormEnhanced();

    // تحقق أساسي
    if (!item.name || !item.sku) return toast("الاسم و كود المنتج مطلوبان");
    if (!item.section) return toast("اختر قسمًا");

    // تحقق أن الفئة (إن وُجدت) تتبع القسم المحدد
    if (item.category){
      const sObj = sections().find(s => s.name === item.section);
      const ok = sObj && categories().some(c => c.sectionId === sObj.id && c.name === item.category);
      if (!ok) return toast("الفئة لا تنتمي للقسم المحدد");
    }

    // تحقق حسب النوع
    if (item.type === "simple"){
      if (Number(item.price) <= 0) return toast("أدخل سعرًا صالحًا");
      if (Number(item.qty) < 0) return toast("الكمية لا يمكن أن تكون سالبة");
    } else if (item.type === "multi-color"){
      if (!item.colors || !item.colors.length) return toast("أضف لونًا واحدًا على الأقل");
    } else if (item.type === "multi-size"){
      if (!item.sizes || !item.sizes.length) return toast("أضف حجمًا واحدًا على الأقل");
    }

    // SKU فريد
    const all = read(KEYS.PRODUCTS, []);
    const dup = all.some(p =>
      String(p.sku||"").toLowerCase() === String(item.sku||"").toLowerCase() &&
      (mode === "create" || (mode === "update" && item.sku.toLowerCase() !== originalSku))
    );
    if (dup) return toast("SKU مستخدم مسبقًا");

    // حفظ
    const idx = all.findIndex(p => String(p.sku||"").toLowerCase() === originalSku);
    if (idx >= 0) all[idx] = item; else all.unshift(item);
    write(KEYS.PRODUCTS, all);
    toast("تم الحفظ");

    // تحديث حالة زر الحفظ وبيانات المودال
    $("#fmSave").dataset.mode = "update";
    $("#fmSave").dataset.sku  = item.sku || "";

    // عرض التفاصيل مباشرة بعد الحفظ
    $("#pane-view").innerHTML = detailsHTML(item);
    $("#pane-view").hidden = false;
    $("#pane-edit").hidden = true;
    $("#viewBtns").hidden = false;
    $("#editBtns").hidden = true;

    // إعادة بناء الشبكة (نحافظ على الفلاتر الحالية)
    const s = $("#sortQty"); if (s) { const v=s.value; s.value=v; s.dispatchEvent(new Event("change")); }
  }

  // نربط مستمع "حفظ" في طور الإلتقاط لمنع المستمع السابق من Part2
  document.addEventListener("DOMContentLoaded", () => {
    const btn = $("#fmSave");
    if (!btn || btn.dataset.enhanced === "1") return;
    btn.dataset.enhanced = "1";
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();   // يمنع وصول الحدث للمستمع الأقدم
      enhancedSave();
    }, true); // capture = true لضمان التنفيذ أولاً
  });

})();
