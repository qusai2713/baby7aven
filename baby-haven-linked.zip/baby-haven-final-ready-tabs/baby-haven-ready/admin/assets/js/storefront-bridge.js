/* 
 * File: assets/js/storefront-bridge.js
 * Purpose: Safe no-op bridge between Admin and Storefront to avoid 404 & MIME errors.
 * Exposes minimal globals if missing to prevent runtime crashes.
 */
(function(w){
  "use strict";
  // Soft globals used by admin pages when storefront bundle isn't present
  w.BH_settings = w.BH_settings || {
    currency: "ر.ع",
    format: function(v){ try { return (Number(v)||0).toFixed(3) + " ر.ع"; } catch(e){ return v; } }
  };
  // Optional namespaces expected by admin linkage
  w.BH_storefront = w.BH_storefront || {
    ping: function(){ return "ok"; }
  };
})(window);
