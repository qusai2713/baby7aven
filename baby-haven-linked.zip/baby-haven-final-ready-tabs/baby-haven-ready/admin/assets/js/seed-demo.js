/* Baby Haven — Demo Seed
   Seeds minimal data ONLY if localStorage is empty, to help first-run previews.
*/
(function(){
  try {
    var LS_KEY = 'bh_products';
    var existing = localStorage.getItem(LS_KEY);
    if (existing && existing !== '[]') return; // do nothing if user already has data

    var demo = [
      { id: 'BH-TOY-0001', name: 'مكعبات مغناطيسية', price: 6.900, qty: 24, image: 'assets/img/demo/mag-cubes.jpg', category: 'ألعاب', sku:'BH-TOY-0001' },
      { id: 'BH-TOY-0002', name: 'طقم سيليكون للطعام', price: 4.500, qty: 18, image: 'assets/img/demo/silicone-set.jpg', category: 'مستلزمات', sku:'BH-TOY-0002' },
      { id: 'BH-TOY-0003', name: 'متاهة خشبية تعليمية', price: 7.200, qty: 12, image: 'assets/img/demo/wood-maze.jpg', category: 'تعليمي', sku:'BH-TOY-0003' }
    ];
    localStorage.setItem(LS_KEY, JSON.stringify(demo));
    // Optional toast:
    console && console.log && console.log('BH demo seed applied (bh_products).');
  } catch(e){ /* silent */ }
})();
