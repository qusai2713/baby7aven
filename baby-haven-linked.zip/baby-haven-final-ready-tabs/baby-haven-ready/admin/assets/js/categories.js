/* =======================================================
📁 File: assets/js/categories.js
📚 إدارة الأقسام والفئات (CRUD + تصدير/استيراد JSON)
======================================================= */

(function () {
  "use strict";

  const { $, $$, toast, uid } = window.BH;
  const { KEYS, read, write } = window.DB;

  let sections = [];
  let categories = [];

  function load() {
    sections = read(KEYS.SECTIONS, []);
    categories = read(KEYS.CATEGORIES, []);
    renderTable();
    fillCategorySectionSelect();
  }

  // 🧱 عرض جدول الأقسام
  function renderTable() {
    const tbody = $("#sectionsTable tbody");
    const products = read(KEYS.PRODUCTS, []);
    tbody.innerHTML = "";

    for (const sec of sections) {
      const cats = categories.filter(c => c.sectionId === sec.id);
      const countProducts = products.filter(p => p.section === sec.name).length;

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${sec.name}</td>
        <td>${cats.length}</td>
        <td>${countProducts}</td>
        <td>${sec.status === "active" ? "🟢 نشط" : "⚪ غير نشط"}</td>
        <td>${new Date(sec.updatedAt).toLocaleDateString("ar-OM")}</td>
        <td>
          <button class="btn xs" data-act="edit" data-id="${sec.id}">✏️</button>
          <button class="btn xs danger" data-act="del" data-id="${sec.id}">🗑️</button>
        </td>`;
      tbody.appendChild(tr);
    }

    if (!sections.length)
      tbody.innerHTML = `<tr><td colspan="6" style="color:var(--muted);padding:20px;">لا توجد أقسام بعد.</td></tr>`;
  }

  // 🧩 تعبئة قائمة الأقسام داخل مودال الفئة
  function fillCategorySectionSelect() {
    const sel = $("#catSection");
    if (!sel) return;
    sel.innerHTML = '<option value="">— اختر القسم —</option>';
    sections.forEach(s => {
      const opt = document.createElement("option");
      opt.value = s.id;
      opt.textContent = s.name;
      sel.appendChild(opt);
    });
  }

  // ➕ إضافة أو تعديل قسم
  $("#btnAddSection").onclick = () => openSectionModal();
  $("#secCancel").onclick = () => $("#bdSection").hidden = true;
  $("#secSave").onclick = saveSection;

  function openSectionModal(id = null) {
    const bd = $("#bdSection");
    bd.hidden = false;
    $("#ttlSection").textContent = id ? "تعديل قسم" : "إضافة قسم";

    if (id) {
      const s = sections.find(x => x.id === id);
      $("#secName").value = s.name;
      $("#secStatus").value = s.status;
      $("#secDesc").value = s.desc;
      $("#secSave").dataset.id = id;
    } else {
      $("#secName").value = "";
      $("#secStatus").value = "active";
      $("#secDesc").value = "";
      delete $("#secSave").dataset.id;
    }
  }

  function saveSection() {
    const name = $("#secName").value.trim();
    const status = $("#secStatus").value;
    const desc = $("#secDesc").value;
    const id = $("#secSave").dataset.id;
    if (!name) return toast("أدخل اسم القسم");

    if (id) {
      const s = sections.find(x => x.id === id);
      s.name = name;
      s.status = status;
      s.desc = desc;
      s.updatedAt = new Date().toISOString();
      toast("تم تعديل القسم");
    } else {
      sections.push({ id: uid("S"), name, status, desc, updatedAt: new Date().toISOString() });
      toast("تمت إضافة قسم جديد");
    }
    write(KEYS.SECTIONS, sections);
    $("#bdSection").hidden = true;
    renderTable();
    fillCategorySectionSelect();
  }

  // 🗑️ حذف قسم
  $("#sectionsTable").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const id = btn.dataset.id;
    const act = btn.dataset.act;

    if (act === "edit") openSectionModal(id);
    if (act === "del") {
      if (!confirm("هل أنت متأكد من حذف هذا القسم؟")) return;
      sections = sections.filter(s => s.id !== id);
      write(KEYS.SECTIONS, sections);
      toast("تم حذف القسم");
      renderTable();
      fillCategorySectionSelect();
    }
  });

  // ➕ إضافة فئة
  $("#btnAddCategory").onclick = () => openCategoryModal();
  $("#catCancel").onclick = () => $("#bdCategory").hidden = true;
  $("#catSave").onclick = saveCategory;

  function openCategoryModal(id = null) {
    const bd = $("#bdCategory");
    bd.hidden = false;
    $("#ttlCategory").textContent = id ? "تعديل فئة" : "إضافة فئة";
    fillCategorySectionSelect();

    if (id) {
      const c = categories.find(x => x.id === id);
      $("#catSection").value = c.sectionId;
      $("#catName").value = c.name;
      $("#catStatus").value = c.status;
      $("#catDesc").value = c.desc;
      $("#catSave").dataset.id = id;
    } else {
      $("#catSection").value = "";
      $("#catName").value = "";
      $("#catStatus").value = "active";
      $("#catDesc").value = "";
      delete $("#catSave").dataset.id;
    }
  }

  function saveCategory() {
    const sectionId = $("#catSection").value;
    const name = $("#catName").value.trim();
    const status = $("#catStatus").value;
    const desc = $("#catDesc").value;
    const id = $("#catSave").dataset.id;

    if (!sectionId || !name) return toast("أكمل جميع الحقول المطلوبة");

    if (id) {
      const c = categories.find(x => x.id === id);
      c.sectionId = sectionId;
      c.name = name;
      c.status = status;
      c.desc = desc;
      c.updatedAt = new Date().toISOString();
      toast("تم تعديل الفئة");
    } else {
      categories.push({ id: uid("C"), sectionId, name, status, desc, updatedAt: new Date().toISOString() });
      toast("تمت إضافة فئة جديدة");
    }

    write(KEYS.CATEGORIES, categories);
    $("#bdCategory").hidden = true;
  }

  // 🔁 تصدير واستيراد JSON
  $("#btnExportCat").onclick = () => {
    const data = { sections, categories };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "categories-export.json";
    a.click();
    toast("تم تصدير البيانات");
  };

  $("#btnImportCat").onclick = () => $("#fileImportCat").click();
  $("#fileImportCat").onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const obj = JSON.parse(reader.result);
        if (obj.sections && obj.categories) {
          write(KEYS.SECTIONS, obj.sections);
          write(KEYS.CATEGORIES, obj.categories);
          toast("تم استيراد البيانات بنجاح");
          load();
        } else toast("ملف غير صالح");
      } catch {
        toast("فشل في قراءة الملف");
      }
    };
    reader.readAsText(file);
  };

  document.addEventListener("DOMContentLoaded", load);
})();
