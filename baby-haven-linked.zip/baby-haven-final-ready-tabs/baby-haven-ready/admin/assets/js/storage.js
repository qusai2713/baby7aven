/* =======================================================
📁 File: assets/js/storage.js
💾 إدارة التخزين المحلي (localStorage) + بيانات أولية
======================================================= */

(function (w) {
  "use strict";

  const KEYS = {
    PRODUCTS: "bh_admin_products_v35",
    SECTIONS: "bh_sections_v10",
    CATEGORIES: "bh_categories_v10",
  };

  // 📦 قراءة وتخزين
  const read = (key, fallback = []) => {
    try {
      return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
    } catch {
      return fallback;
    }
  };

  const write = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // 🌱 تعبئة بيانات تجريبية إذا فاضي
  function seedIfEmpty() {
    if (!localStorage.getItem(KEYS.SECTIONS)) {
      const section = { id: "S1", name: "ملابس", status: "active", desc: "قسم الملابس", updatedAt: new Date().toISOString() };
      const category = { id: "C1", sectionId: "S1", name: "بيجامات", status: "active", desc: "فئة البيجامات", updatedAt: new Date().toISOString() };
      write(KEYS.SECTIONS, [section]);
      write(KEYS.CATEGORIES, [category]);
    }
    if (!localStorage.getItem(KEYS.PRODUCTS)) {
      const product = {
        type: "simple",
        name: "بطانية أطفال ناعمة",
        sku: "BH-BLKT-001",
        section: "ملابس",
        category: "بيجامات",
        price: 6.500,
        qty: 8,
        desc: "- قطنية 100%\n- لطيفة على بشرة الطفل",
        image: "",
        updatedAt: new Date().toISOString(),
      };
      write(KEYS.PRODUCTS, [product]);
    }
  }

  // 🧹 أدوات مساعدة
  const remove = (key) => localStorage.removeItem(key);
  const clearAll = () => Object.values(KEYS).forEach((k) => localStorage.removeItem(k));

  w.DB = { KEYS, read, write, seedIfEmpty, remove, clearAll };
})(window);
