/* =======================================================
📁 File: assets/js/discounts.js
🏷️ تبويب الخصومات: CRUD + تحقق + تصدير/استيراد
======================================================= */

(function () {
  "use strict";

  const { $, $$, toast, uid } = window.BH;

  // ====== التخزين ======
  const KEY = "bh_discounts_v1";
  const read = () => {
    try { return JSON.parse(localStorage.getItem(KEY) || "[]"); }
    catch { return []; }
  };
  const write = (arr) => localStorage.setItem(KEY, JSON.stringify(arr));

  // ====== حالة محلية ======
  let list = [];

  // ====== أدوات عرض ======
  const fmtMoney = (v) => `${Number(v || 0).toFixed(3)} ر.ع`;
  const fmtDate = (iso) => iso ? new Date(iso).toLocaleString("ar-OM") : "—";
  const dispType = (t, v) => t === "percent" ? `${v}%` : fmtMoney(v);

  function dispScope(scp) {
    if (!scp) return "—";
    if (scp === "all" || scp.scope === "all") return "كل المنتجات";
    const s = scp.sections?.length ? `أقسام (${scp.sections.length})` : "";
    const c = scp.categories?.length ? `فئات (${scp.categories.length})` : "";
    const k = scp.skus?.length ? `SKU (${scp.skus.length})` : "";
    return [s, c, k].filter(Boolean).join(" | ") || "—";
  }

  // ====== بناء الصفوف ======
  function render() {
    const tbody = $("#discountsTable tbody");
    tbody.innerHTML = "";

    if (!list.length) {
      tbody.innerHTML = `<tr><td colspan="9" style="color:var(--muted);padding:20px;text-align:center">
        لا توجد خصومات بعد — اضغط "إضافة خصم".
      </td></tr>`;
      return;
    }

    // ترتيب افتراضي: الأحدث تحديثًا أولًا
    const arr = list.slice().sort((a, b) => new Date(b.updatedAt||0) - new Date(a.updatedAt||0));

    for (const d of arr) {
      const tr = document.createElement("tr");
      const scopeText = dispScope(d.scope === "all" ? "all" : d.scope);
      const spanAct = d.active ? "🟢 نشط" : "⚪ غير نشط";
      const spanExc = d.exclusive ? "نعم" : "لا";
      const duration = `${fmtDate(d.startAt||"")} → ${fmtDate(d.endAt||"")}`;

      tr.innerHTML = `
        <td><code class="sku">${d.code}</code></td>
        <td>${dispType(d.type, d.value)}</td>
        <td>${scopeText}</td>
        <td>${duration}</td>
        <td>${d.minOrder ? fmtMoney(d.minOrder) : "—"}</td>
        <td>${spanExc}</td>
        <td>${spanAct}</td>
        <td>${fmtDate(d.updatedAt)}</td>
        <td>
          <button class="btn xs" data-act="edit" data-id="${d.id}">✏️</button>
          <button class="btn xs" data-act="toggle" data-id="${d.id}">${d.active ? "إيقاف" : "تفعيل"}</button>
          <button class="btn xs danger" data-act="del" data-id="${d.id}">🗑️</button>
        </td>
      `;
      tbody.appendChild(tr);
    }
  }

  // ====== فتح/ملء المودال ======
  function openModal(id = null) {
    $("#bdDiscount").hidden = false;
    document.body.style.overflow = "hidden";
    $("#ttlDiscount").textContent = id ? "تعديل خصم" : "إضافة خصم";
    $("#dcSave").dataset.id = id || "";

    if (!id) {
      // افتراضي إنشاء
      $("#dcCode").value = "";
      $("#dcActive").value = "true";
      $("#dcExclusive").value = "false";
      $("#dcType").value = "percent";
      $("#dcValue").value = "";
      $("#dcMinOrder").value = "";
      $("#dcScope").value = "all";
      $("#dcScopeValues").value = "";
      $("#dcStartAt").value = "";
      $("#dcEndAt").value = "";
      return;
    }

    const d = list.find(x => x.id === id);
    if (!d) return;

    $("#dcCode").value = d.code || "";
    $("#dcActive").value = String(!!d.active);
    $("#dcExclusive").value = String(!!d.exclusive);
    $("#dcType").value = d.type || "percent";
    $("#dcValue").value = d.value ?? "";
    $("#dcMinOrder").value = d.minOrder ?? "";

    if (d.scope === "all") {
      $("#dcScope").value = "all";
      $("#dcScopeValues").value = "";
    } else if (d.scope?.sections?.length) {
      $("#dcScope").value = "sections";
      $("#dcScopeValues").value = d.scope.sections.join(", ");
    } else if (d.scope?.categories?.length) {
      $("#dcScope").value = "categories";
      $("#dcScopeValues").value = d.scope.categories.join(", ");
    } else if (d.scope?.skus?.length) {
      $("#dcScope").value = "skus";
      $("#dcScopeValues").value = d.scope.skus.join(", ");
    } else {
      $("#dcScope").value = "all";
      $("#dcScopeValues").value = "";
    }

    // تعبئة التاريخ (datetime-local يتطلب شكل YYYY-MM-DDTHH:mm)
    const toLocalInput = (iso) => {
      if (!iso) return "";
      const dte = new Date(iso);
      const pad = (n) => String(n).padStart(2, "0");
      const y = dte.getFullYear();
      const m = pad(dte.getMonth()+1);
      const d = pad(dte.getDate());
      const hh = pad(dte.getHours());
      const mm = pad(dte.getMinutes());
      return `${y}-${m}-${d}T${hh}:${mm}`;
    };
    $("#dcStartAt").value = toLocalInput(d.startAt || "");
    $("#dcEndAt").value   = toLocalInput(d.endAt || "");
  }

  function closeModal() {
    $("#bdDiscount").hidden = true;
    document.body.style.overflow = "";
  }

  // ====== قراءة نموذج الخصم ======
  function parseList(txt) {
    return String(txt || "")
      .split(",")
      .map(s => s.trim())
      .filter(Boolean);
  }

  function readForm() {
    const code = String($("#dcCode").value || "").trim().toUpperCase();
    const active = $("#dcActive").value === "true";
    const exclusive = $("#dcExclusive").value === "true";
    const type = $("#dcType").value;
    const value = Number($("#dcValue").value || 0);
    const minOrder = $("#dcMinOrder").value === "" ? null : Number($("#dcMinOrder").value);
    const scopeKind = $("#dcScope").value;
    const scopeValues = parseList($("#dcScopeValues").value);

    let scope = "all";
    if (scopeKind === "sections") scope = { sections: scopeValues };
    else if (scopeKind === "categories") scope = { categories: scopeValues };
    else if (scopeKind === "skus") scope = { skus: scopeValues };

    // datetime-local → ISO
    const toISO = (v) => {
      const s = String(v || "").trim();
      if (!s) return null;
      // اعتِماد المنطقة الزمنية الحالية للمتصفح
      const d = new Date(s);
      return isNaN(d.getTime()) ? null : d.toISOString();
    };

    const startAt = toISO($("#dcStartAt").value);
    const endAt   = toISO($("#dcEndAt").value);

    return {
      code, type, value, minOrder,
      scope,
      exclusive, active,
      startAt, endAt
    };
  }

  // ====== التحقق ======
  function validate(d, editingId = null) {
    if (!d.code) return "أدخل كود الخصم";
    if (!/^[A-Z0-9\-]+$/.test(d.code)) return "الكود يجب أن يكون أحرف/أرقام/شرطات وبأحرف كبيرة";
    if (list.some(x => x.code === d.code && x.id !== editingId)) return "الكود مستخدم مسبقًا";

    if (d.type !== "percent" && d.type !== "fixed") return "نوع الخصم غير صالح";
    if (d.type === "percent") {
      if (isNaN(d.value) || d.value < 0 || d.value > 100) return "النسبة يجب أن تكون بين 0 و 100";
    } else {
      if (isNaN(d.value) || d.value < 0) return "قيمة المبلغ يجب أن تكون ≥ 0";
    }

    if (d.minOrder !== null && (isNaN(d.minOrder) || d.minOrder < 0)) return "الحد الأدنى غير صالح";

    // النطاق
    if (d.scope !== "all") {
      const hasAny = (d.scope.sections?.length || d.scope.categories?.length || d.scope.skus?.length);
      if (!hasAny) return "أضف قيماً للنطاق أو اختر (كل المنتجات)";
    }

    // المدة
    if (d.startAt && d.endAt) {
      if (new Date(d.startAt) > new Date(d.endAt)) return "تاريخ البداية يجب أن يسبق النهاية";
    }

    return null;
  }

  // ====== حفظ (إنشاء/تعديل) ======
  function save() {
    const id = $("#dcSave").dataset.id || null;
    const data = readForm();
    const err = validate(data, id);
    if (err) { toast(err); return; }

    const now = new Date().toISOString();

    if (!id) {
      // إنشاء
      const rec = {
        id: uid("D"),
        createdAt: now,
        updatedAt: now,
        ...data
      };
      list.unshift(rec);
      toast("تمت إضافة خصم جديد");
    } else {
      // تعديل
      const idx = list.findIndex(x => x.id === id);
      if (idx < 0) { toast("العنصر غير موجود"); return; }
      list[idx] = { ...list[idx], ...data, updatedAt: now };
      toast("تم تعديل الخصم");
    }

    write(list);
    closeModal();
    render();
  }

  // ====== أحداث الجدول ======
  $("#discountsTable").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const id = btn.dataset.id;
    const act = btn.dataset.act;

    if (act === "edit") {
      openModal(id);
    } else if (act === "del") {
      const rec = list.find(x => x.id === id);
      if (!rec) return;
      const ok = confirm(`حذف الخصم ${rec.code}؟`);
      if (!ok) return;
      list = list.filter(x => x.id !== id);
      write(list);
      render();
      toast("تم حذف الخصم");
    } else if (act === "toggle") {
      const rec = list.find(x => x.id === id);
      if (!rec) return;
      rec.active = !rec.active;
      rec.updatedAt = new Date().toISOString();
      write(list);
      render();
      toast(rec.active ? "تم تفعيل الخصم" : "تم إيقاف الخصم");
    }
  });

  // ====== فتح/إغلاق المودال ======
  $("#btnAddDiscount").addEventListener("click", () => openModal(null));
  $("#dcCancel").addEventListener("click", closeModal);
  $("#dcSave").addEventListener("click", save);

  // ====== تصدير/استيراد ======
  $("#btnExportDiscounts").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(list, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "discounts-export.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 0);
    toast("تم تصدير الخصومات");
  });

  $("#btnImportDiscounts").addEventListener("click", () => $("#fileImportDiscounts").click());
  $("#fileImportDiscounts").addEventListener("change", function () {
    const f = this.files && this.files[0];
    if (!f) return;
    const fr = new FileReader();
    fr.onload = (e) => {
      try {
        const arr = JSON.parse(String(e.target.result || "[]"));
        if (!Array.isArray(arr)) throw new Error("صيغة غير صحيحة");

        // دمج حسب code (Uppercase)
        const map = new Map(list.map(d => [String(d.code).toUpperCase(), d]));
        const now = new Date().toISOString();

        let imported = 0;
        for (const raw of arr) {
          if (!raw || typeof raw !== "object") continue;
          const code = String(raw.code || "").toUpperCase();
          if (!code) continue;

          const rec = {
            id: raw.id || uid("D"),
            code,
            type: raw.type === "fixed" ? "fixed" : "percent",
            value: Number(raw.value || 0),
            minOrder: (raw.minOrder === null || raw.minOrder === undefined) ? null : Number(raw.minOrder),
            scope: (function(){
              if (raw.scope === "all" || raw.scope?.scope === "all") return "all";
              return {
                sections: Array.isArray(raw.scope?.sections) ? raw.scope.sections.map(String) : undefined,
                categories: Array.isArray(raw.scope?.categories) ? raw.scope.categories.map(String) : undefined,
                skus: Array.isArray(raw.scope?.skus) ? raw.scope.skus.map(String) : undefined,
              };
            })(),
            exclusive: !!raw.exclusive,
            active: !!raw.active,
            startAt: raw.startAt || null,
            endAt: raw.endAt || null,
            createdAt: raw.createdAt || now,
            updatedAt: now
          };

          // تحقق سريع قبل الدمج
          const err = validate(rec, null);
          if (err) continue;

          map.set(code, { ...map.get(code), ...rec }); // إدراج/تحديث
          imported++;
        }

        list = Array.from(map.values());
        write(list);
        render();
        toast(`تم الاستيراد (${imported}) خصم/خصومات`);
      } catch (err) {
        console.error(err);
        toast("فشل الاستيراد: تحقق من الملف");
      } finally {
        this.value = "";
      }
    };
    fr.readAsText(f);
  });

  // ====== تحميل أولي ======
  document.addEventListener("DOMContentLoaded", () => {
    list = read();
    render();
  });

})();
