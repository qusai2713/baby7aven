// # Header Block
// File: assets/js/admin/admin-core.js
// Purpose: نظام التبويبات (tablist/tab/tabpanel) مع ARIA صحيحة + روڤينغ tabindex + منع الفوكس داخل اللوحات المخفية + Toast موحّد

(function () {
  "use strict";

  /* ==========================
     Helpers
  ========================== */
  const $  = (s, p = document) => p.querySelector(s);
  const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));

  // عناصر قابلة للتركيز (سنوقفها عندما تكون اللوحة مخفية)
  const FOCUSABLE =
    'a[href],area[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]';

  // بثّ رسالة وصولية في live region (إن وُجد)
  function announce(msg) {
    const live = $("#aria-live");
    if (!live) return;
    live.textContent = msg || "";
  }

  /* ==========================
     Toast (موحّد)
  ========================== */
  window.toast = function toast(msg, type = "info", { duration = 1800 } = {}) {
    // لو موجود عنصر جاهز في الصفحة (id="toast-root") نستخدمه
    let root = $("#toast-root");
    if (!root) {
      root = document.createElement("div");
      root.id = "toast-root";
      root.className = "toast";
      root.setAttribute("aria-live", "polite");
      root.setAttribute("aria-atomic", "true");
      document.body.appendChild(root);
    }
    root.textContent = String(msg || "");
    root.hidden = false;
    root.classList.add("show");
    window.clearTimeout(root._t);
    root._t = window.setTimeout(() => {
      root.classList.remove("show");
      root.hidden = true;
    }, duration);
  };

  /* ==========================
     Panels Show/Hide + Focus Guard
  ========================== */
  function setPanelHidden(panel, hidden) {
    if (!panel) return;
    panel.hidden = hidden;
    panel.setAttribute("aria-hidden", hidden ? "true" : "false");

    // امنع/أعد الفوكس داخل اللوحة
    $$(FOCUSABLE, panel).forEach((el) => {
      if (hidden) {
        if (!el.hasAttribute("data-old-tabindex") && el.hasAttribute("tabindex")) {
          el.setAttribute("data-old-tabindex", el.getAttribute("tabindex"));
        }
        el.setAttribute("tabindex", "-1");
      } else {
        if (el.hasAttribute("data-old-tabindex")) {
          el.setAttribute("tabindex", el.getAttribute("data-old-tabindex"));
          el.removeAttribute("data-old-tabindex");
        } else {
          el.removeAttribute("tabindex"); // نعيد للوضع الطبيعي
        }
      }
    });
  }

  /* ==========================
     Activate Tab
  ========================== */
  function activateTab(tabBtn, { focusPanel = false } = {}) {
    if (!tabBtn) return;

    const tablist = tabBtn.closest('[role="tablist"]');
    const tabs = $$('[role="tab"]', tablist || document);
    const panels = $$(".tab-panel");

    // عطّل جميع التبويبات
    tabs.forEach((t) => {
      t.classList.remove("is-active");
      t.setAttribute("aria-selected", "false");
      t.setAttribute("tabindex", "-1");
    });

    // أخفِ جميع اللوحات
    panels.forEach((p) => setPanelHidden(p, true));

    // فعّل التبويب الحالي
    tabBtn.classList.add("is-active");
    tabBtn.setAttribute("aria-selected", "true");
    tabBtn.setAttribute("tabindex", "0");

    // أظهر لوحته
    const panelId = tabBtn.getAttribute("aria-controls");
    const panel = panelId ? document.getElementById(panelId) : null;
    if (panel) {
      setPanelHidden(panel, false);
      if (focusPanel) {
        // تركيز اختياري على بداية اللوحة
        panel.focus();
      }
    }

    // إعلان وصولي
    announce(`تم فتح تبويب: ${tabBtn.textContent.trim()}`);
  }

  /* ==========================
     Click handlers
  ========================== */
  document.addEventListener("click", (e) => {
    const btn = e.target.closest('[role="tab"]');
    if (!btn) return;
    activateTab(btn);
  });

  /* ==========================
     Keyboard Navigation
     الأسهم يمين/يسار + Home/End
  ========================== */
  document.addEventListener("keydown", (e) => {
    const cur = e.target.closest('[role="tab"]');
    if (!cur) return;

    const list = cur.closest('[role="tablist"]');
    const tabs = $$('[role="tab"]', list || document);
    let i = tabs.indexOf(cur);

    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
      e.preventDefault();
      i =
        e.key === "ArrowRight"
          ? (i + 1) % tabs.length
          : (i - 1 + tabs.length) % tabs.length;
      tabs[i].focus();
      activateTab(tabs[i]);
    } else if (e.key === "Home") {
      e.preventDefault();
      tabs[0].focus();
      activateTab(tabs[0]);
    } else if (e.key === "End") {
      e.preventDefault();
      tabs[tabs.length - 1].focus();
      activateTab(tabs[tabs.length - 1]);
    }
  });

  /* ==========================
     Initial Boot
  ========================== */
  window.addEventListener("DOMContentLoaded", () => {
    // فعّل أول تبويب إن لم يكن مفعّلًا
    const first = document.querySelector(
      '[role="tablist"] [role="tab"].is-active'
    ) || document.querySelector('[role="tablist"] [role="tab"]');

    if (first) {
      // تأكد من حالة اللوحات عند البدء
      activateTab(first);
    }

    // محتويات افتراضية خفيفة (لما تكون الملفات الأخرى لسه ما حقنت شيء)
    const ordersPanel = $("#tab-orders");
    if (ordersPanel && !ordersPanel.dataset._init) {
      ordersPanel.dataset._init = "1";
      if (!ordersPanel.querySelector(".table")) {
        ordersPanel.innerHTML = `
          <div class="table-responsive">
            <table class="table">
              <thead><tr><th>رقم</th><th>العميل</th><th>الإجمالي</th><th>الحالة</th><th>إجراءات</th></tr></thead>
              <tbody id="ordersBody">
                <tr>
                  <td>1001</td>
                  <td>عميل تجريبي</td>
                  <td>12.000 ر.ع</td>
                  <td><span class="chip">قيد المراجعة</span></td>
                  <td><button class="btn btn--ghost">تفاصيل</button></td>
                </tr>
              </tbody>
            </table>
          </div>`;
      }
    }
  });
})();
