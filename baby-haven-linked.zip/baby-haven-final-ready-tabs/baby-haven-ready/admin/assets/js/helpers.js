/* =======================================================
📁 File: assets/js/helpers.js
🧰 أدوات عامة (اختصارات DOM + إشعارات + تنسيقات)
======================================================= */

(function (w) {
  "use strict";

  const $ = (s, p = document) => p.querySelector(s);
  const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));

  const toast = (msg, type = "info") => {
    const wrap = $("#toasts");
    if (!wrap) return;
    const el = document.createElement("div");
    el.className = `toast toast-${type}`;
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(() => el.remove(), 2500);
  };

  const fmt = (v) => {
    const n = Number(v) || 0;
    return `${n.toFixed(3)} ر.ع`;
  };

  const esc = (str = "") =>
    String(str).replace(/[&<>\"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[ch]));

  const uid = (prefix = "id") =>
    `${prefix}-${Math.random().toString(36).slice(2, 9)}`;

  w.BH = { $, $$, toast, fmt, esc, uid };
})(window);
