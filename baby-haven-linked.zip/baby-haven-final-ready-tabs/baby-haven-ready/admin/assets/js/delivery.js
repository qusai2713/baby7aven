/* =======================================================
📁 File: assets/js/delivery.js
🚚 إعدادات التوصيل: الشرائح + الحفظ/القراءة + تصدير/استيراد
======================================================= */

(function () {
  "use strict";

  const { $, toast } = window.BH;

  const KEY = "bh_delivery_v1";

  // القيم الافتراضية حسب اتفاقنا:
  const defaults = {
    enabled: true,
    calcOn: "after_discount", // after_discount | before_discount
    tiers: [
      { kind: "lt",  max: 10.000,  fee: 2.000 },                // أقل من 10 → 2.000
      { kind: "rng", min: 10.000, max: 20.000, fee: 1.000 },    // 10–<20 → 1.000
      { kind: "gte", min: 20.000, fee: 0.000 }                   // ≥20 → مجاني
    ],
    note: ""
  };

  // قراءة/كتابة
  function read() {
    try { return JSON.parse(localStorage.getItem(KEY) || JSON.stringify(defaults)); }
    catch { return { ...defaults }; }
  }
  function write(data) { localStorage.setItem(KEY, JSON.stringify(data)); }

  // تعبئة المودال
  function fillForm() {
    const st = read();
    $("#dlvEnabled").checked = !!st.enabled;
    $("#dlvCalcOn").value = st.calcOn || "after_discount";

    const t1 = st.tiers[0] || defaults.tiers[0];
    const t2 = st.tiers[1] || defaults.tiers[1];
    const t3 = st.tiers[2] || defaults.tiers[2];

    $("#t1Max").value = Number(t1.max ?? 10).toFixed(3);
    $("#t1Fee").value = Number(t1.fee ?? 2).toFixed(3);

    $("#t2Min").value = Number(t2.min ?? 10).toFixed(3);
    $("#t2Max").value = Number(t2.max ?? 20).toFixed(3);
    $("#t2Fee").value = Number(t2.fee ?? 1).toFixed(3);

    $("#t3Min").value = Number(t3.min ?? 20).toFixed(3);
    $("#t3Fee").value = Number(t3.fee ?? 0).toFixed(3);
    $("#dlvNote").value = st.note || "";
  }

  // قراءة النموذج
  const toNum = (x) => {
    const n = Number(x);
    return isNaN(n) ? 0 : n;
  };

  function readForm() {
    const enabled = $("#dlvEnabled").checked;
    const calcOn = $("#dlvCalcOn").value;

    const t1Max = toNum($("#t1Max").value);
    const t1Fee = toNum($("#t1Fee").value);

    const t2Min = toNum($("#t2Min").value);
    const t2Max = toNum($("#t2Max").value);
    const t2Fee = toNum($("#t2Fee").value);

    const t3Min = toNum($("#t3Min").value);
    const t3Fee = toNum($("#t3Fee").value);

    const note = ($("#dlvNote").value || "").trim();

    return {
      enabled,
      calcOn,
      tiers: [
        { kind: "lt",  max: t1Max,           fee: t1Fee },
        { kind: "rng", min: t2Min, max: t2Max, fee: t2Fee },
        { kind: "gte", min: t3Min,           fee: t3Fee }
      ],
      note
    };
  }

  // تحقق
  function validate(cfg) {
    // رسوم غير سالبة
    for (const t of cfg.tiers) {
      if (toNum(t.fee) < 0) return "رسوم الشحن لا يمكن أن تكون سالبة";
    }
    // تَدرّج الحدود: t1.max < t2.min < t2.max ≤ t3.min
    const a = toNum(cfg.tiers[0].max);
    const b1 = toNum(cfg.tiers[1].min);
    const b2 = toNum(cfg.tiers[1].max);
    const c = toNum(cfg.tiers[2].min);

    if (!(a > 0)) return "حد شريحة 1 (أقل من) يجب أن يكون أكبر من صفر";
    if (!(b1 >= a)) return "بداية شريحة 2 يجب أن تساوي أو تتجاوز نهاية شريحة 1";
    if (!(b2 > b1)) return "نهاية شريحة 2 يجب أن تكون أكبر من بدايتها";
    if (!(c >= b2)) return "شريحة 3 (من) يجب أن تساوي أو تتجاوز نهاية شريحة 2";
    // الشريحة 3 عادة مجانية — لكن لو وضع المستخدم رسومًا، سنسمح بها (مرونة).

    return null;
  }

  // حفظ
  function save() {
    const cfg = readForm();

    // تقريب ثلاث منازل
    cfg.tiers = cfg.tiers.map(t => ({
      ...t,
      fee: Number(toNum(t.fee).toFixed(3)),
      min: t.min !== undefined ? Number(toNum(t.min).toFixed(3)) : undefined,
      max: t.max !== undefined ? Number(toNum(t.max).toFixed(3)) : undefined
    }));

    const err = validate(cfg);
    if (err) return toast(err);

    write(cfg);
    toast("تم حفظ إعدادات التوصيل");
    close();
  }

  // حساب رسوم الشحن (يمكن استدعاؤها من الواجهة لاحقًا)
  function calcShipping(subtotal, discountApplied = 0, mode = null) {
    const cfg = read();
    if (!cfg.enabled) return 0;

    const calcOn = mode || cfg.calcOn || "after_discount";
    const base = calcOn === "after_discount" ? (subtotal - discountApplied) : subtotal;
    const total = Math.max(0, Number(base));

    const t1 = cfg.tiers[0], t2 = cfg.tiers[1], t3 = cfg.tiers[2];
    if (total < Number(t1.max)) return Number(t1.fee);
    if (total >= Number(t2.min) && total < Number(t2.max)) return Number(t2.fee);
    if (total >= Number(t3.min)) return Number(t3.fee);
    return 0;
  }

  // فتح/إغلاق
  function open() {
    fillForm();
    $("#bdDelivery").hidden = false;
    document.body.style.overflow = "hidden";
  }
  function close() {
    $("#bdDelivery").hidden = true;
    document.body.style.overflow = "";
  }

  // تصدير/استيراد
  function exportCfg() {
    const cfg = read();
    const blob = new Blob([JSON.stringify(cfg, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "delivery-export.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 0);
    toast("تم تصدير إعدادات التوصيل");
  }
  function importCfg(file) {
    const fr = new FileReader();
    fr.onload = (e) => {
      try {
        const obj = JSON.parse(String(e.target.result || "{}"));
        const merged = {
          ...defaults,
          ...obj,
          tiers: Array.isArray(obj.tiers) && obj.tiers.length === 3 ? obj.tiers : defaults.tiers
        };
        const err = validate(merged);
        if (err) return toast(err);
        write(merged);
        fillForm();
        toast("تم الاستيراد والحفظ");
      } catch {
        toast("فشل الاستيراد: تحقق من صيغة الملف");
      } finally {
        $("#dlvFileImport").value = "";
      }
    };
    fr.readAsText(file);
  }

  // ربط الأحداث
  document.addEventListener("DOMContentLoaded", () => {
    $("#btnDeliveryOpen")?.addEventListener("click", open);
    $("#dlvCancel")?.addEventListener("click", close);
    $("#dlvSave")?.addEventListener("click", save);
    $("#dlvExport")?.addEventListener("click", exportCfg);
    $("#dlvImport")?.addEventListener("click", () => $("#dlvFileImport").click());
    $("#dlvFileImport")?.addEventListener("change", function () {
      const f = this.files && this.files[0];
      if (f) importCfg(f);
    });

    // تأمين خانة رسوم الشريحة 3 (غالبًا مجانية)
    $("#t3Fee")?.setAttribute("disabled", "disabled");
  });

  // إتاحة دالة الحساب للواجهة (cart/checkout)
  window.BH_Delivery = { calcShipping };

})();
