// # Header Block
// File: assets/js/admin/settings.js
// Purpose: إعدادات عامة + ربط لاحق لمفاتيح الدفع (UAT) — بدون حفظ مفاتيح سرية في الواجهة
(function(){
  "use strict";
  const root=document.getElementById('tab-settings'); if(!root) return;
  root.innerHTML = `
    <h3>الإعدادات</h3>
    <p class="muted">هذا التبويب مخصص لإعداد خيارات العرض والتنسيق. مفاتيح الدفع (Secret Key) تحفظ في الخادم الوسيط فقط.</p>
  `;

  window.BH_settings = {
    format(v){ return (Number(v)||0).toFixed(3) + ' ر.ع'; }
  };
})();