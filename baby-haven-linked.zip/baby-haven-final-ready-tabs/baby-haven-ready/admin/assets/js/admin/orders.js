// # Header Block
// File: assets/js/admin/orders.js
// Purpose: إدارة الطلبات — عرض/بحث/تصفية/تفاصيل/تغيير حالة/حذف/طباعة (محفوظ محليًا)

(function () {
  "use strict";

  /* ==========================
     Constants + Utils
  ========================== */
  const LS_ORDERS = "bh_orders";
  const $ = (s, p = document) => p.querySelector(s);
  const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));

  const fmt = (v) =>
    (window.BH_settings?.format?.(Number(v) || 0)) ??
    `${(Number(v) || 0).toFixed(3)} ر.ع`;

  function readOrders() {
    try {
      return JSON.parse(localStorage.getItem(LS_ORDERS) || "[]");
    } catch {
      return [];
    }
  }
  function writeOrders(v) {
    localStorage.setItem(LS_ORDERS, JSON.stringify(v));
  }

  // Seed تجريبي لو فاضي
  function seedIfEmpty() {
    const cur = readOrders();
    if (cur.length) return;
    const demo = [
      {
        id: "ORD-1001",
        customer: { name: "قصي المنذري", phone: "9xxxxxxx", city: "مسقط" },
        items: [
          { sku: "BH-TOY-0001", name: "مكعبات مغناطيسية", qty: 2, price: 3.7 },
          { sku: "BH-TOY-0002", name: "حصيرة لعب", qty: 1, price: 7.9 },
        ],
        subTotal: 15.3,
        shipping: 1.0,
        discount: 0.0,
        total: 16.3,
        status: "pending", // pending | paid | shipped | delivered | cancelled
        createdAt: Date.now() - 86400000,
        note: "",
      },
      {
        id: "ORD-1002",
        customer: { name: "عميل تجريبي", phone: "9xxxxxxx", city: "السيب" },
        items: [{ sku: "BH-TOY-0003", name: "حلقة تكديس سيليكون", qty: 1, price: 4.2 }],
        subTotal: 4.2,
        shipping: 2.0,
        discount: 0.2,
        total: 6.0,
        status: "paid",
        createdAt: Date.now(),
        note: "توصيل صباحًا",
      },
    ];
    writeOrders(demo);
  }

  function fmtDate(ts) {
    try {
      return new Date(ts).toLocaleString("ar-SA");
    } catch {
      return "-";
    }
  }

  function statusChip(v) {
    const map = {
      pending: { label: "قيد المراجعة", cls: "chip" },
      paid: { label: "مدفوع", cls: "chip chip--available" },
      shipped: { label: "تم الشحن", cls: "chip chip--low" },
      delivered: { label: "تم التسليم", cls: "chip chip--almost" },
      cancelled: { label: "ملغي", cls: "chip chip--out" },
    };
    const m = map[v] || map.pending;
    return `<span class="${m.cls}">${m.label}</span>`;
  }

  function escapeHtml(s) {
    return String(s ?? "").replace(/[&<>\"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[ch]);
  }

  /* ==========================
     Root + Render
  ========================== */
  const root = $("#tab-orders");
  if (!root) return;

  seedIfEmpty();

  root.innerHTML = `
    <div class="flex" style="justify-content: space-between; align-items:center; margin-bottom:8px;">
      <div class="flex">
        <input id="ordSearch" class="input" type="search" placeholder="بحث: رقم/اسم/هاتف/SKU" autocomplete="off" />
        <select id="ordStatus" style="min-width:160px">
          <option value="">كل الحالات</option>
          <option value="pending">قيد المراجعة</option>
          <option value="paid">مدفوع</option>
          <option value="shipped">تم الشحن</option>
          <option value="delivered">تم التسليم</option>
          <option value="cancelled">ملغي</option>
        </select>
      </div>
      <div class="flex">
        <button class="btn btn--ghost" id="btnRefresh">تحديث</button>
        <button class="btn" id="btnExport">تصدير CSV</button>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table" id="ordersTable">
        <thead>
          <tr>
            <th>رقم الطلب</th>
            <th>العميل</th>
            <th>الإجمالي</th>
            <th>الحالة</th>
            <th>التاريخ</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody id="ordersBody"></tbody>
      </table>
    </div>

    <!-- Dialog: تفاصيل -->
    <div class="modal" id="ordModal" hidden aria-hidden="true">
      <div class="modal__dialog" role="dialog" aria-modal="true" aria-labelledby="ordModalTitle">
        <h3 id="ordModalTitle" style="margin-top:0">تفاصيل الطلب</h3>
        <div id="ordModalBody"></div>
        <div class="form-actions" style="margin-top:12px">
          <button class="btn" id="btnPrint">طباعة</button>
          <button class="btn btn--ghost" id="btnCloseModal">إغلاق</button>
        </div>
      </div>
    </div>
  `;

  function deriveTotal(o) {
    const sub = Number(o.subTotal || 0);
    const sh = Number(o.shipping || 0);
    const d = Number(o.discount || 0);
    return +(sub + sh - d).toFixed(3);
  }

  function renderTable() {
    const list = readOrders();
    const tbody = $("#ordersBody", root);
    const q = ($("#ordSearch", root).value || "").trim().toLowerCase();
    const sf = $("#ordStatus", root).value || "";
    const rows = list.filter((o) => {
      const txt = `${o.id} ${o.customer?.name || ""} ${o.customer?.phone || ""} ${o.items?.map(i=>i.sku).join(" ")}`;
      const matchQ = !q || txt.toLowerCase().includes(q);
      const matchS = !sf || o.status === sf;
      return matchQ && matchS;
    });

    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center muted">لا توجد نتائج.</td></tr>`;
      return;
    }

    tbody.innerHTML = rows
      .map((o) => {
        const total = deriveTotal(o);
        return `
        <tr data-id="${escapeHtml(o.id)}">
          <td><strong>${escapeHtml(o.id)}</strong></td>
          <td>
            <div class="stack">
              <span>${escapeHtml(o.customer?.name || "-")}</span>
              <small class="muted">${escapeHtml(o.customer?.phone || "")} • ${escapeHtml(o.customer?.city || "")}</small>
            </div>
          </td>
          <td>${fmt(total)}</td>
          <td>${statusChip(o.status)}</td>
          <td><small>${fmtDate(o.createdAt)}</small></td>
          <td>
            <div class="flex">
              <button class="btn btn--sm" data-act="view">تفاصيل</button>
              <button class="btn btn--sm" data-act="status">تغيير الحالة</button>
              <button class="btn btn--sm btn--ghost" data-act="delete">حذف</button>
            </div>
          </td>
        </tr>`;
      })
      .join("");
  }

  /* ==========================
     Modal Helpers
  ========================== */
  const modal = $("#ordModal", root);
  const modalBody = $("#ordModalBody", root);

  function openModal() {
    modal.hidden = false;
    modal.setAttribute("aria-hidden", "false");
  }
  function closeModal() {
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
  }

  function renderDetails(order) {
    const lines = (order.items || [])
      .map(
        (it) => `
        <tr>
          <td>${escapeHtml(it.name)}</td>
          <td><code>${escapeHtml(it.sku)}</code></td>
          <td>${Number(it.qty || 0)}</td>
          <td>${fmt(it.price)}</td>
          <td>${fmt((it.qty || 0) * (it.price || 0))}</td>
        </tr>`
      )
      .join("");

    modalBody.innerHTML = `
      <div class="grid grid-2">
        <div class="card">
          <h4 style="margin:0 0 6px">العميل</h4>
          <div class="stack">
            <div><strong>${escapeHtml(order.customer?.name || "-")}</strong></div>
            <div class="muted">${escapeHtml(order.customer?.phone || "")} • ${escapeHtml(order.customer?.city || "")}</div>
            ${order.note ? `<div class="muted">ملاحظة: ${escapeHtml(order.note)}</div>` : ""}
          </div>
        </div>
        <div class="card">
          <h4 style="margin:0 0 6px">الملخص</h4>
          <div class="stack">
            <div>الإجمالي الفرعي: <strong>${fmt(order.subTotal)}</strong></div>
            <div>الشحن: <strong>${fmt(order.shipping)}</strong></div>
            <div>الخصم: <strong>${fmt(order.discount)}</strong></div>
            <div>الإجمالي: <strong>${fmt(deriveTotal(order))}</strong></div>
            <div>الحالة: ${statusChip(order.status)}</div>
            <div class="muted">الوقت: ${fmtDate(order.createdAt)}</div>
          </div>
        </div>
      </div>

      <div class="table-responsive" style="margin-top:12px">
        <table class="table">
          <thead>
            <tr><th>المنتج</th><th>SKU</th><th>الكمية</th><th>السعر</th><th>المجموع</th></tr>
          </thead>
          <tbody>${lines}</tbody>
        </table>
      </div>
    `;
  }

  /* ==========================
     Actions
  ========================== */
  function getOrderById(id) {
    return readOrders().find((x) => x.id === id) || null;
  }

  function setStatus(id, status) {
    const list = readOrders();
    const idx = list.findIndex((x) => x.id === id);
    if (idx === -1) return false;
    list[idx].status = status;
    writeOrders(list);
    return true;
  }

  function deleteOrder(id) {
    const list = readOrders().filter((x) => x.id !== id);
    writeOrders(list);
  }

  function exportCSV() {
    const rows = readOrders();
    const headers = [
      "id",
      "customer_name",
      "phone",
      "city",
      "subtotal",
      "shipping",
      "discount",
      "total",
      "status",
      "createdAt",
      "items_count",
    ];
    const lines = [headers.join(",")];
    for (const o of rows) {
      lines.push(
        [
          q(o.id),
          q(o.customer?.name || ""),
          q(o.customer?.phone || ""),
          q(o.customer?.city || ""),
          q(String(o.subTotal || 0)),
          q(String(o.shipping || 0)),
          q(String(o.discount || 0)),
          q(String(deriveTotal(o))),
          q(o.status),
          q(new Date(o.createdAt || Date.now()).toISOString()),
          q(String((o.items || []).length)),
        ].join(",")
      );
    }
    const blob = new Blob(["\ufeff" + lines.join("\n")], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "orders.csv";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  const q = (s) => `"${String(s ?? "").replace(/"/g, '""')}"`;

  function printOrder(order) {
    const w = window.open("", "_blank", "width=900,height=700");
    if (!w) return;
    const rows = (order.items || [])
      .map(
        (it) =>
          `<tr><td>${escapeHtml(it.name)}</td><td>${escapeHtml(
            it.sku
          )}</td><td>${it.qty}</td><td>${fmt(it.price)}</td><td>${fmt(
            it.qty * it.price
          )}</td></tr>`
      )
      .join("");
    w.document.write(`
      <html lang="ar" dir="rtl">
        <head>
          <meta charset="utf-8" />
          <title>طباعة ${escapeHtml(order.id)}</title>
          <style>
            body{font-family:Tahoma,Arial,sans-serif;line-height:1.7}
            table{width:100%;border-collapse:collapse}
            th,td{border:1px solid #999;padding:6px;text-align:right}
          </style>
        </head>
        <body>
          <h3>فاتورة — ${escapeHtml(order.id)}</h3>
          <p><strong>العميل:</strong> ${escapeHtml(order.customer?.name || "-")} — ${
      order.customer?.phone || ""
    } — ${escapeHtml(order.customer?.city || "")}</p>
          <table>
            <thead><tr><th>المنتج</th><th>SKU</th><th>الكمية</th><th>السعر</th><th>المجموع</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
          <p><strong>الإجمالي:</strong> ${fmt(deriveTotal(order))}</p>
          <script>window.print();</script>
        </body>
      </html>
    `);
    w.document.close();
  }

  /* ==========================
     Bindings
  ========================== */
  function bind() {
    // تحديث الجدول
    $("#btnRefresh", root).addEventListener("click", () => {
      renderTable();
      window.toast?.("تم التحديث");
    });

    // تصدير
    $("#btnExport", root).addEventListener("click", exportCSV);

    // بحث/فلترة
    $("#ordSearch", root).addEventListener("input", renderTable);
    $("#ordStatus", root).addEventListener("change", renderTable);

    // جدول الإجراءات
    $("#ordersTable", root).addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      const tr = e.target.closest("tr");
      const id = tr?.getAttribute("data-id");
      if (!id) return;

      const order = getOrderById(id);
      if (!order) return;

      if (btn.dataset.act === "view") {
        renderDetails(order);
        openModal();
      } else if (btn.dataset.act === "status") {
        // اختيار سريع للحالة
        const next = prompt(
          "أدخل الحالة: pending | paid | shipped | delivered | cancelled",
          order.status
        );
        const allowed = ["pending", "paid", "shipped", "delivered", "cancelled"];
        if (!next || !allowed.includes(next)) return;
        if (setStatus(id, next)) {
          window.toast?.("تم تحديث الحالة");
          renderTable();
        }
      } else if (btn.dataset.act === "delete") {
        if (!confirm(`حذف الطلب ${id}؟`)) return;
        deleteOrder(id);
        window.toast?.("تم الحذف");
        renderTable();
      }
    });

    // مودال
    $("#btnCloseModal", root).addEventListener("click", closeModal);
    $("#btnPrint", root).addEventListener("click", () => {
      const id = $("#ordModalBody", root).dataset?.id;
      // نطبع آخر طلب مُعرض في الواجهة (نعتمد variable محلي)
      const rows = readOrders();
      const o =
        rows.find((x) => $("#ordModalBody", root).innerHTML.includes(x.id)) ||
        rows[0];
      if (o) printOrder(o);
    });
  }

  // إعادة رندر التفاصيل تحفظ الـ id داخل body للمودال (لو أردتها)
  const _renderDetails = renderDetails;
  renderDetails = function (order) {
    $("#ordModalBody", root).dataset.id = order.id;
    _renderDetails(order);
  };

  // إقلاع
  renderTable();
  bind();
})();
