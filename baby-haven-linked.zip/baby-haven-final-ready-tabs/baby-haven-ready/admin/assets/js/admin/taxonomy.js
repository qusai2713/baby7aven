// # Header Block
// File: assets/js/admin/taxonomy.js
// Purpose: إدارة الأقسام والفئات (CRUD) — تخزين محلي KEY_TAXONOMY + واجهة مبسطة لقسمين: الأقسام والفئات

(function () {
  "use strict";
  const KEY = "KEY_TAXONOMY";
  const $ = (s, p = document) => p.querySelector(s);
  const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));

  const rootS = $("#tab-sections");
  const rootC = $("#tab-categories");
  if (!rootS || !rootC) return;

  const read = () => {
    try { return JSON.parse(localStorage.getItem(KEY) || "{}"); }
    catch { return {}; }
  };
  const write = (v) => localStorage.setItem(KEY, JSON.stringify(v));
  const esc = (s) => String(s ?? "").replace(/[&<>\"']/g, (ch) => ({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[ch]));

  function render() {
    const data = read();
    const sections = Object.keys(data);

    // الأقسام
    rootS.innerHTML = `
      <div class="flex" style="justify-content:space-between;align-items:center;margin-bottom:8px;">
        <h3 style="margin:0">الأقسام</h3>
        <div class="flex">
          <input id="newSec" class="input" placeholder="اسم القسم" />
          <button id="addSec" class="btn">إضافة قسم</button>
        </div>
      </div>
      <div class="table-responsive">
        <table class="table">
          <thead><tr><th>القسم</th><th>عدد الفئات</th><th>إجراءات</th></tr></thead>
          <tbody id="secList">
            ${sections.length ? sections.map(s => `
              <tr data-id="${esc(s)}">
                <td><strong>${esc(s)}</strong></td>
                <td>${(data[s]||[]).length}</td>
                <td>
                  <div class="flex">
                    <button class="btn btn--sm" data-act="use">تحديد لإدارة فئاته</button>
                    <button class="btn btn--sm" data-act="rename">إعادة تسمية</button>
                    <button class="btn btn--sm btn--danger" data-act="del">حذف</button>
                  </div>
                </td>
              </tr>`).join("") : `<tr><td colspan="3" class="text-center muted">لا أقسام بعد.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;

    // الفئات (نعرض أول قسم افتراضيًا أو المختار سابقًا)
    const active = rootC.dataset.activeSection || sections[0] || "";
    const cats = active ? (data[active] || []) : [];
    rootC.innerHTML = `
      <div class="flex" style="justify-content:space-between;align-items:center;margin-bottom:8px;">
        <h3 style="margin:0">الفئات ${active ? `— <small class="muted">${esc(active)}</small>` : ""}</h3>
        <div class="flex">
          <select id="catSection" ${sections.length? "":"disabled"}>
            ${sections.map(s => `<option value="${esc(s)}" ${s===active?"selected":""}>${esc(s)}</option>`).join("")}
          </select>
          <input id="newCat" class="input" placeholder="اسم الفئة" ${active? "":"disabled"} />
          <button id="addCat" class="btn" ${active? "":"disabled"}>إضافة فئة</button>
        </div>
      </div>
      <div class="table-responsive">
        <table class="table">
          <thead><tr><th>الفئة</th><th>إجراءات</th></tr></thead>
          <tbody id="catList">
            ${cats.length ? cats.map(c => `
              <tr data-id="${esc(c)}">
                <td>${esc(c)}</td>
                <td>
                  <div class="flex">
                    <button class="btn btn--sm" data-act="rename">إعادة تسمية</button>
                    <button class="btn btn--sm btn--danger" data-act="del">حذف</button>
                  </div>
                </td>
              </tr>`).join("") : `<tr><td colspan="2" class="text-center muted">لا فئات لهذا القسم.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;

    bind();
  }

  function bind() {
    const data = read();

    // إضافة قسم
    $("#addSec", rootS).onclick = () => {
      const name = ($("#newSec", rootS).value || "").trim();
      if (!name) return;
      if (data[name]) { window.toast?.("القسم موجود بالفعل"); return; }
      data[name] = [];
      write(data);
      rootC.dataset.activeSection = name;
      render();
      window.toast?.("تمت إضافة القسم");
    };

    // أحداث الأقسام (use/rename/del)
    $("#secList", rootS).onclick = (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      const tr = e.target.closest("tr");
      const id = tr?.getAttribute("data-id");
      if (!id) return;

      if (btn.dataset.act === "use") {
        rootC.dataset.activeSection = id;
        render();
      } else if (btn.dataset.act === "rename") {
        const nn = prompt("اسم جديد للقسم:", id) || "";
        if (!nn) return;
        if (data[nn] && nn !== id) { window.toast?.("اسم مستخدم"); return; }
        data[nn] = data[id] || [];
        if (nn !== id) delete data[id];
        write(data);
        rootC.dataset.activeSection = nn;
        render();
      } else if (btn.dataset.act === "del") {
        if (!confirm(`حذف القسم "${id}"؟ ستُحذف فئاته أيضًا.`)) return;
        delete data[id];
        write(data);
        delete rootC.dataset.activeSection;
        render();
      }
    };

    // اختيار قسم من القائمة المنسدلة لإدارة فئاته
    const sel = $("#catSection", rootC);
    if (sel) {
      sel.onchange = () => {
        rootC.dataset.activeSection = sel.value;
        render();
      };
    }

    // إضافة فئة
    const addCatBtn = $("#addCat", rootC);
    if (addCatBtn) {
      addCatBtn.onclick = () => {
        const sec = rootC.dataset.activeSection;
        if (!sec) return;
        const name = ($("#newCat", rootC).value || "").trim();
        if (!name) return;
        const d = read();
        d[sec] = d[sec] || [];
        if (d[sec].includes(name)) { window.toast?.("الفئة موجودة"); return; }
        d[sec].push(name);
        write(d);
        render();
        window.toast?.("تمت إضافة الفئة");
      };
    }

    // أحداث الفئات (rename/del)
    $("#catList", rootC).onclick = (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      const tr = e.target.closest("tr");
      const id = tr?.getAttribute("data-id");
      const sec = rootC.dataset.activeSection;
      if (!id || !sec) return;

      const d = read();
      d[sec] = d[sec] || [];

      if (btn.dataset.act === "rename") {
        const nn = prompt("اسم جديد للفئة:", id) || "";
        if (!nn) return;
        if (d[sec].includes(nn) && nn !== id) { window.toast?.("اسم مستخدم"); return; }
        d[sec] = d[sec].map((x) => (x === id ? nn : x));
        write(d);
        render();
      } else if (btn.dataset.act === "del") {
        if (!confirm(`حذف الفئة "${id}"؟`)) return;
        d[sec] = d[sec].filter((x) => x !== id);
        write(d);
        render();
      }
    };
  }

  render();
})();
