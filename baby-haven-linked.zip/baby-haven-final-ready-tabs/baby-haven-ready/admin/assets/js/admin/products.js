

(function () {
  "use strict";

  /* ==========================
     Constants + Utils
  ========================== */
  const LS_PRODUCTS = "bh_products";
  const $ = (s, p = document) => p.querySelector(s);
  const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));

  const fmtMoney =
    window.BH_settings?.format ??
    ((v) => `${(Number(v) || 0).toFixed(3)} ر.ع`);

  const uid = () => Math.random().toString(36).slice(2);

  function read() {
    try {
      return JSON.parse(localStorage.getItem(LS_PRODUCTS) || "[]");
    } catch {
      return [];
    }
  }
  function write(v) {
    localStorage.setItem(LS_PRODUCTS, JSON.stringify(v));
  }

  function escapeHtml(s) {
    return String(s ?? "").replace(/[&<>\"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[ch]);
  }

  /* ==========================
     Seed (اختياري)
  ========================== */
  function seedIfEmpty() {
    const cur = read();
    if (cur.length) return;
    write([
      {
        id: uid(),
        name: "مكعبات مغناطيسية",
        sku: "BH-TOY-0001",
        type: "colors", // colors
        price: 3.5,
        section: "ألعاب",
        category: "تعليمية",
        cover: "",
        desc: "مكعبات لتنمية المهارات.",
        colors: [
          { name: "أحمر", price: 3.7, qty: 5, img: "" },
          { name: "أزرق", price: 3.6, qty: 2, img: "" },
        ],
        sizes: [],
        qty: 0,
        createdAt: Date.now(),
        lastMod: Date.now(),
      },
      {
        id: uid(),
        name: "حصيرة لعب",
        sku: "BH-TOY-0002",
        type: "sizes", // sizes
        price: 7.9,
        section: "أطفال",
        category: "مفروشات",
        cover: "",
        desc: "حصيرة لعب سهلة التنظيف.",
        colors: [],
        sizes: [
          { name: "صغير", price: 7.9, qty: 12 },
          { name: "كبير", price: 9.9, qty: 3 },
        ],
        qty: 0,
        createdAt: Date.now(),
        lastMod: Date.now(),
      },
      {
        id: uid(),
        name: "بوتل رضاعة",
        sku: "BH-FEED-0003",
        type: "simple", // simple
        price: 2.5,
        section: "مواليد",
        category: "رضاعة",
        cover: "",
        desc: "زجاجة مع صمام ضد المغص.",
        colors: [],
        sizes: [],
        qty: 20,
        createdAt: Date.now(),
        lastMod: Date.now(),
      },
    ]);
  }

  /* ==========================
     Root + Scaffold
  ========================== */
  const root = $("#tab-products");
  if (!root) return;

  seedIfEmpty();

  root.innerHTML = `
    <div class="flex" style="justify-content:space-between;align-items:center;margin-bottom:8px;">
      <div class="flex">
        <input id="pSearch" class="input" type="search" placeholder="بحث: اسم/SKU/قسم/فئة" autocomplete="off" />
        <select id="pType" style="min-width:160px">
          <option value="">كل الأنواع</option>
          <option value="simple">عادي</option>
          <option value="colors">متعدد الألوان</option>
          <option value="sizes">متعدد الأحجام</option>
        </select>
      </div>
      <div class="flex">
        <button class="btn btn--ghost" id="pExport">تصدير CSV</button>
        <button class="btn" id="pNew">منتج جديد</button>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table" id="pTable">
        <thead>
          <tr>
            <th>الصورة</th>
            <th>الاسم</th>
            <th>SKU</th>
            <th>النوع</th>
            <th>القسم/الفئة</th>
            <th>السعر</th>
            <th>الكمية</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody id="pBody"></tbody>
      </table>
    </div>

    <!-- Dialog: نموذج المنتج -->
    <div class="modal" id="pModal" hidden aria-hidden="true">
      <div class="modal__dialog" role="dialog" aria-modal="true" aria-labelledby="pModalTitle">
        <h3 id="pModalTitle" style="margin:0 0 10px">المنتج</h3>

        <form id="pForm" class="grid grid-2">
          <label>الاسم <input name="name" required maxlength="120" /></label>
          <label>SKU <input name="sku" required maxlength="64" /></label>

          <label>النوع
            <select name="type" required>
              <option value="simple">عادي</option>
              <option value="colors">متعدد الألوان</option>
              <option value="sizes">متعدد الأحجام</option>
            </select>
          </label>
          <label>السعر الأساسي <input name="price" type="number" step="0.001" min="0" value="0" /></label>

          <label>القسم <input name="section" maxlength="64" placeholder="مثال: ألعاب" /></label>
          <label>الفئة <input name="category" maxlength="64" placeholder="مثال: تعليمية" /></label>

          <label class="grid" style="grid-column:1 / -1">الوصف
            <textarea name="desc" rows="3" placeholder="وصف مختصر يدعم النقاط/الجمل"></textarea>
          </label>

          <div class="grid" style="grid-column:1 / -1">
            <span class="muted">صورة الغلاف (اختياري)</span>
            <div id="coverDrop" class="card" style="padding:10px; text-align:center">
              <input type="file" id="coverInput" accept="image/*" hidden />
              <button class="btn btn--ghost" id="coverPick" type="button">اختيار صورة</button>
              <div id="coverPreview" class="center" style="margin-top:8px"></div>
            </div>
          </div>

          <!-- Variants: Colors -->
          <div id="colorsBox" class="grid" style="grid-column:1 / -1; display:none">
            <div class="flex" style="justify-content:space-between; align-items:center;">
              <h4 style="margin:0">متغيرات الألوان</h4>
              <button class="btn btn--sm" id="addColor" type="button">+ إضافة لون</button>
            </div>
            <div id="colorsList" class="grid"></div>
          </div>

          <!-- Variants: Sizes -->
          <div id="sizesBox" class="grid" style="grid-column:1 / -1; display:none">
            <div class="flex" style="justify-content:space-between; align-items:center;">
              <h4 style="margin:0">متغيرات الأحجام</h4>
              <button class="btn btn--sm" id="addSize" type="button">+ إضافة مقاس</button>
            </div>
            <div id="sizesList" class="grid"></div>
          </div>

          <!-- Simple qty -->
          <div id="simpleQtyRow" style="grid-column:1 / -1; display:none">
            <label>الكمية <input name="qty" type="number" step="1" min="0" value="0" /></label>
          </div>

          <div class="form-actions" style="grid-column:1 / -1">
            <button type="submit" class="btn">حفظ</button>
            <button type="button" id="pCancel" class="btn btn--ghost">إلغاء</button>
          </div>
        </form>
      </div>
    </div>
  `;

  /* ==========================
     Render
  ========================== */
  function renderTable() {
    const list = read();
    const tbody = $("#pBody", root);
    const q = ($("#pSearch", root).value || "").toLowerCase().trim();
    const tf = $("#pType", root).value || "";

    const rows = list.filter((p) => {
      const t =
        `${p.name} ${p.sku} ${p.section || ""} ${p.category || ""}`.toLowerCase();
      const mQ = !q || t.includes(q);
      const mT = !tf || p.type === tf;
      return mQ && mT;
    });

    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center muted">لا توجد منتجات.</td></tr>`;
      return;
    }

    tbody.innerHTML = rows
      .map((p) => {
        const img = p.cover
          ? `<img src="${escapeHtml(p.cover)}" alt="" style="width:40px;height:40px;object-fit:cover;border-radius:8px" />`
          : `<div class="rounded-lg shadow-sm" style="width:40px;height:40px;background:#0f172a;display:grid;place-items:center">🧸</div>`;

        const qty =
          p.type === "simple"
            ? Number(p.qty || 0)
            : p.type === "colors"
            ? (p.colors || []).reduce((a, c) => a + (Number(c.qty || 0) || 0), 0)
            : (p.sizes || []).reduce((a, s) => a + (Number(s.qty || 0) || 0), 0);

        return `
          <tr data-id="${escapeHtml(p.id)}">
            <td>${img}</td>
            <td><strong>${escapeHtml(p.name)}</strong><br><small class="muted">${escapeHtml(
          p.desc || ""
        )}</small></td>
            <td><code>${escapeHtml(p.sku)}</code></td>
            <td>${p.type === "simple" ? "عادي" : p.type === "colors" ? "ألوان" : "أحجام"}</td>
            <td>${escapeHtml(p.section || "-")}/${escapeHtml(p.category || "-")}</td>
            <td>${fmtMoney(p.price)}</td>
            <td><strong>${qty}</strong></td>
            <td>
              <div class="flex">
                <button class="btn btn--sm" data-act="edit">تعديل</button>
                <button class="btn btn--sm btn--ghost" data-act="delete">حذف</button>
              </div>
            </td>
          </tr>`;
      })
      .join("");
  }

  /* ==========================
     Modal + Form
  ========================== */
  const modal = $("#pModal", root);
  const form = $("#pForm", root);
  const cancelBtn = $("#pCancel", root);
  const coverInput = $("#coverInput", root);
  const coverPick = $("#coverPick", root);
  const coverPreview = $("#coverPreview", root);
  const coverDrop = $("#coverDrop", root);

  const colorsBox = $("#colorsBox", root);
  const colorsList = $("#colorsList", root);
  const addColor = $("#addColor", root);

  const sizesBox = $("#sizesBox", root);
  const sizesList = $("#sizesList", root);
  const addSize = $("#addSize", root);

  const simpleQtyRow = $("#simpleQtyRow", root);

  let editingId = null;

  function openModal() {
    modal.hidden = false;
    modal.setAttribute("aria-hidden", "false");
  }
  function closeModal() {
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
  }

  function resetForm() {
    form.reset();
    coverPreview.innerHTML = "";
    colorsList.innerHTML = "";
    sizesList.innerHTML = "";
    editingId = null;
    toggleTypeUI(form.type.value || "simple");
  }

  function toggleTypeUI(type) {
    colorsBox.style.display = type === "colors" ? "block" : "none";
    sizesBox.style.display = type === "sizes" ? "block" : "none";
    simpleQtyRow.style.display = type === "simple" ? "block" : "none";
  }

  function fillForm(p) {
    form.name.value = p.name || "";
    form.sku.value = p.sku || "";
    form.type.value = p.type || "simple";
    form.price.value = Number(p.price || 0);
    form.section.value = p.section || "";
    form.category.value = p.category || "";
    form.desc.value = p.desc || "";
    if (p.type === "simple") form.qty.value = Number(p.qty || 0);
    toggleTypeUI(p.type);

    coverPreview.innerHTML = p.cover
      ? `<img src="${escapeHtml(p.cover)}" alt="" style="max-width:160px;border-radius:12px" />`
      : "";

    colorsList.innerHTML = "";
    (p.colors || []).forEach((c) => addColorRow(c));
    sizesList.innerHTML = "";
    (p.sizes || []).forEach((s) => addSizeRow(s));
  }

  function collectForm() {
    const base = {
      name: form.name.value.trim(),
      sku: form.sku.value.trim(),
      type: form.type.value,
      price: Number(form.price.value || 0),
      section: form.section.value.trim(),
      category: form.category.value.trim(),
      cover:
        coverPreview.querySelector("img")?.getAttribute("src") ||
        (coverPreview.dataset.blobUrl || ""),
      desc: form.desc.value.trim(),
    };
    if (base.type === "simple") {
      return {
        ...base,
        qty: Math.max(0, Math.floor(Number(form.qty.value || 0))),
        colors: [],
        sizes: [],
      };
    } else if (base.type === "colors") {
      const items = $$("[data-color-row]", colorsList).map((row) => ({
        name: row.querySelector('[name="cname"]').value.trim() || "-",
        price: Number(row.querySelector('[name="cprice"]').value || base.price),
        qty: Math.max(
          0,
          Math.floor(Number(row.querySelector('[name="cqty"]').value || 0))
        ),
        img: row.querySelector("img")?.getAttribute("src") || "",
      }));
      return { ...base, colors: items, sizes: [], qty: 0 };
    } else {
      const items = $$("[data-size-row]", sizesList).map((row) => ({
        name: row.querySelector('[name="sname"]').value.trim() || "-",
        price: Number(row.querySelector('[name="sprice"]').value || base.price),
        qty: Math.max(
          0,
          Math.floor(Number(row.querySelector('[name="sqty"]').value || 0))
        ),
      }));
      return { ...base, sizes: items, colors: [], qty: 0 };
    }
  }

  /* ==========================
     Variant Rows
  ========================== */
  function addColorRow(c = { name: "", price: 0, qty: 0, img: "" }) {
    const id = uid();
    const wrap = document.createElement("div");
    wrap.setAttribute("data-color-row", id);
    wrap.className = "card";
    wrap.innerHTML = `
      <div class="grid grid-3">
        <label>اللون <input name="cname" value="${escapeHtml(c.name || "")}" /></label>
        <label>السعر <input name="cprice" type="number" step="0.001" min="0" value="${Number(c.price || 0)}" /></label>
        <label>الكمية <input name="cqty" type="number" step="1" min="0" value="${Number(c.qty || 0)}" /></label>
      </div>
      <div class="flex" style="justify-content:space-between; align-items:center; margin-top:8px;">
        <div>
          <input type="file" accept="image/*" id="cimg-${id}" hidden />
          <button class="btn btn--sm btn--ghost" type="button" data-act="pick-img">اختيار صورة</button>
        </div>
        <div class="flex">
          <button class="btn btn--sm" type="button" data-act="dup">نسخ</button>
          <button class="btn btn--sm btn--danger" type="button" data-act="del">حذف</button>
        </div>
      </div>
      <div class="center" style="margin-top:6px" data-preview>
        ${
          c.img
            ? `<img src="${escapeHtml(
                c.img
              )}" alt="" style="max-width:140px;border-radius:10px" />`
            : `<small class="muted">لا توجد صورة</small>`
        }
      </div>
    `;
    colorsList.appendChild(wrap);

    const file = wrap.querySelector(`#cimg-${id}`);
    const pick = wrap.querySelector('[data-act="pick-img"]');
    const prev = wrap.querySelector("[data-preview]");

    pick.addEventListener("click", () => file.click());
    file.addEventListener("change", (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      const url = URL.createObjectURL(f);
      prev.innerHTML = `<img src="${url}" alt="" style="max-width:140px;border-radius:10px" />`;
    });

    wrap.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      if (btn.dataset.act === "del") {
        wrap.remove();
      } else if (btn.dataset.act === "dup") {
        addColorRow({
          name: wrap.querySelector('[name="cname"]').value,
          price: wrap.querySelector('[name="cprice"]').value,
          qty: wrap.querySelector('[name="cqty"]').value,
          img: wrap.querySelector("img")?.getAttribute("src") || "",
        });
      }
    });
  }

  function addSizeRow(s = { name: "", price: 0, qty: 0 }) {
    const id = uid();
    const wrap = document.createElement("div");
    wrap.setAttribute("data-size-row", id);
    wrap.className = "card";
    wrap.innerHTML = `
      <div class="grid grid-3">
        <label>المقاس <input name="sname" value="${escapeHtml(s.name || "")}" /></label>
        <label>السعر <input name="sprice" type="number" step="0.001" min="0" value="${Number(s.price || 0)}" /></label>
        <label>الكمية <input name="sqty" type="number" step="1" min="0" value="${Number(s.qty || 0)}" /></label>
      </div>
      <div class="form-actions" style="margin-top:8px">
        <button class="btn btn--sm" type="button" data-act="dup">نسخ</button>
        <button class="btn btn--sm btn--danger" type="button" data-act="del">حذف</button>
      </div>
    `;
    sizesList.appendChild(wrap);

    wrap.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      if (btn.dataset.act === "del") {
        wrap.remove();
      } else if (btn.dataset.act === "dup") {
        addSizeRow({
          name: wrap.querySelector('[name="sname"]').value,
          price: wrap.querySelector('[name="sprice"]').value,
          qty: wrap.querySelector('[name="sqty"]').value,
        });
      }
    });
  }

  /* ==========================
     Image Cover (pick/drag-drop)
  ========================== */
  coverPick.addEventListener("click", () => coverInput.click());
  coverInput.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const url = URL.createObjectURL(f);
    coverPreview.innerHTML = `<img src="${url}" alt="" style="max-width:160px;border-radius:12px" />`;
    coverPreview.dataset.blobUrl = url;
  });

  coverDrop.addEventListener("dragover", (e) => {
    e.preventDefault();
    coverDrop.style.border = "1px dashed #38bdf8";
  });
  coverDrop.addEventListener("dragleave", () => {
    coverDrop.style.border = "none";
  });
  coverDrop.addEventListener("drop", (e) => {
    e.preventDefault();
    coverDrop.style.border = "none";
    const f = e.dataTransfer.files?.[0];
    if (!f) return;
    const url = URL.createObjectURL(f);
    coverPreview.innerHTML = `<img src="${url}" alt="" style="max-width:160px;border-radius:12px" />`;
    coverPreview.dataset.blobUrl = url;
  });

  /* ==========================
     Bindings
  ========================== */
  $("#pSearch", root).addEventListener("input", renderTable);
  $("#pType", root).addEventListener("change", renderTable);
  $("#pExport", root).addEventListener("click", exportCSV);

  $("#pNew", root).addEventListener("click", () => {
    resetForm();
    editingId = null;
    openModal();
  });

  $("#pTable", root).addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-act]");
    if (!btn) return;
    const tr = e.target.closest("tr");
    const id = tr?.getAttribute("data-id");
    if (!id) return;

    const list = read();
    const idx = list.findIndex((x) => x.id === id);
    if (idx === -1) return;

    if (btn.dataset.act === "edit") {
      resetForm();
      editingId = id;
      fillForm(list[idx]);
      openModal();
    } else if (btn.dataset.act === "delete") {
      if (!confirm("حذف المنتج؟")) return;
      write(list.filter((x) => x.id !== id));
      window.toast?.("تم الحذف");
      renderTable();
    }
  });

  form.type.addEventListener("change", (e) => toggleTypeUI(e.target.value));
  addColor.addEventListener("click", () => addColorRow());
  addSize.addEventListener("click", () => addSizeRow());
  cancelBtn.addEventListener("click", closeModal);

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = collectForm();
    const list = read();

    if (editingId) {
      const idx = list.findIndex((x) => x.id === editingId);
      if (idx !== -1) {
        list[idx] = {
          ...list[idx],
          ...data,
          id: editingId,
          lastMod: Date.now(),
        };
      }
    } else {
      list.unshift({
        id: uid(),
        ...data,
        createdAt: Date.now(),
        lastMod: Date.now(),
      });
    }
    write(list);
    closeModal();
    window.toast?.("تم الحفظ");
    renderTable();
  });

  /* ==========================
     Export CSV
  ========================== */
  function exportCSV() {
    const rows = read();
    const headers = [
      "name",
      "sku",
      "type",
      "price",
      "section",
      "category",
      "qty_total",
      "createdAt",
      "lastMod",
    ];
    const lines = [headers.join(",")];

    for (const p of rows) {
      const qty =
        p.type === "simple"
          ? Number(p.qty || 0)
          : p.type === "colors"
          ? (p.colors || []).reduce((a, c) => a + (Number(c.qty || 0) || 0), 0)
          : (p.sizes || []).reduce((a, s) => a + (Number(s.qty || 0) || 0), 0);
      lines.push(
        [
          q(p.name),
          q(p.sku),
          q(p.type),
          q(String(p.price || 0)),
          q(p.section || ""),
          q(p.category || ""),
          q(String(qty)),
          q(new Date(p.createdAt || Date.now()).toISOString()),
          q(new Date(p.lastMod || Date.now()).toISOString()),
        ].join(",")
      );
    }

    const blob = new Blob(["\ufeff" + lines.join("\n")], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "products.csv";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  const q = (s) => `"${String(s ?? "").replace(/"/g, '""')}"`;

  /* ==========================
     Boot
  ========================== */
  renderTable();
})();
