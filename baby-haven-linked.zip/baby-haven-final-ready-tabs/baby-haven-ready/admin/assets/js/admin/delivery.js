// # Header Block
// File: assets/js/admin/delivery.js
// Purpose: قواعد التوصيل العُمانية + API evaluate()
(function(){
  "use strict";
  const root=document.getElementById('tab-delivery'); if(!root) return;
  root.innerHTML = `<p class="muted">قواعد التوصيل: أقل من 10 = 2 ر.ع، 10–20 = 1 ر.ع، أكثر من 20 = مجاني.</p>`;

  window.BH_delivery = {
    evaluate(total){
      total = Number(total)||0;
      if (total < 10) return {fee:2, label:'أقل من 10 ر.ع'};
      if (total <= 20) return {fee:1, label:'10–20 ر.ع'};
      return {fee:0, label:'توصيل مجاني'};
    }
  };
})();