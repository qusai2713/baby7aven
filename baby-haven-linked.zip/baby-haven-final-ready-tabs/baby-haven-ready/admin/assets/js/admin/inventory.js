// # Header Block
// File: assets/js/admin/inventory.js
// Purpose: إدارة المخزون — جدول + تعديل كميات (+/−) + سجل تعديلات + حالة تلقائية + فلاتر + تصدير CSV

(function(){
  "use strict";

  /* ==========================
     Constants + Utilities
  ========================== */
  const LS_PRODUCTS   = 'bh_products';      // من products.js
  const LS_INV_LOG    = 'bh_inventory_log'; // سجل تعديلات المخزون

  const $  = (s,p=document)=> p.querySelector(s);
  const $$ = (s,p=document)=> Array.from(p.querySelectorAll(s));

  const read = (k, d=[])=> { try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(d))}catch{return d} };
  const write= (k,v)=> localStorage.setItem(k, JSON.stringify(v));

  const fmtMoney = (v)=> window.BH_settings?.format?.(Number(v)||0) ?? `${(Number(v)||0).toFixed(3)} ر.ع`;
  const fmtDate  = (ts)=> new Date(ts||Date.now()).toLocaleString('ar-SA');

  function toast(msg,type='info',opt={}){ if (window.toast) return window.toast(msg,type,opt); alert(msg); }

  /* ==========================
     Status Logic
  ========================== */
  const STATUS = {
    AVAILABLE:  { key:'available',  label:'متوفر',           icon:'🟩' },
    LOW:        { key:'low',        label:'منخفض',           icon:'🟨' },
    ALMOST_OUT: { key:'almost',     label:'يوشك على النفاد', icon:'🟧' },
    OUT:        { key:'out',        label:'غير متوفر',       icon:'⬜' },
  };

  function computeStatus(qty){
    qty = Number(qty)||0;
    if (qty <= 0) return STATUS.OUT.key;
    if (qty <= 3) return STATUS.ALMOST_OUT.key;   // 1..3
    if (qty <= 9) return STATUS.LOW.key;          // 4..9
    return STATUS.AVAILABLE.key;                  // >=10
  }

  function statusChip(key){
    const m = {
      available: STATUS.AVAILABLE,
      low:       STATUS.LOW,
      almost:    STATUS.ALMOST_OUT,
      out:       STATUS.OUT,
    }[key] || STATUS.OUT;
    return `<span class="chip chip--${m.key}" title="${m.label}">${m.icon} ${m.label}</span>`;
  }

  /* ==========================
     Data Model Helpers
  ========================== */
  function readProducts(){ return read(LS_PRODUCTS, []); }
  function writeProducts(v){ write(LS_PRODUCTS, v); }

  function readInvLog(){ return read(LS_INV_LOG, []); }
  function pushInvLog(entry){
    const logs = readInvLog();
    logs.unshift(entry); // الأحدث أولاً
    write(LS_INV_LOG, logs);
  }

  // رجّع صفوف مسطّحة للمخزون (منتجات بسيطة + تلوين + أحجام)
  function deriveRows(){
    const list = readProducts();
    const rows = [];
    for (const p of list){
      const base = {
        pid: p.id || p.sku || Math.random().toString(36).slice(2),
        name: p.name || '',
        sku:  p.sku  || '',
        section: p.section || p.categoryParent || '',
        category: p.category || '',
        lastMod: p.lastMod || p.updatedAt || p.createdAt || null,
        type: p.type || 'simple', // simple | colors | sizes
      };
      if (base.type === 'colors' && Array.isArray(p.colors)){
        for (const c of p.colors){
          const qty = Number(c.qty||0);
          rows.push({ ...base,
            rowId: `${base.sku}::color::${c.name||c.color}`,
            variantType: 'color',
            variantLabel: c.name || c.color || '-',
            price: Number(c.price ?? p.price ?? 0),
            qty,
            status: computeStatus(qty),
          });
        }
      } else if (base.type === 'sizes' && Array.isArray(p.sizes)){
        for (const s of p.sizes){
          const qty = Number(s.qty||0);
          rows.push({ ...base,
            rowId: `${base.sku}::size::${s.name||s.size}`,
            variantType: 'size',
            variantLabel: s.name || s.size || '-',
            price: Number(s.price ?? p.price ?? 0),
            qty,
            status: computeStatus(qty),
          });
        }
      } else {
        const qty = Number(p.qty||0);
        rows.push({ ...base,
          rowId: `${base.sku}::simple`,
          variantType: null,
          variantLabel: '-',
          price: Number(p.price||0),
          qty,
          status: computeStatus(qty),
        });
      }
    }
    return rows;
  }

  // كتابة الكمية الجديدة إلى هيكل المنتجات الأصلي
  function writeQtyBack(row, newQty){
    const list = readProducts();
    const idx = list.findIndex(x=> (x.sku||'') === row.sku);
    if (idx === -1) return false;
    const p = list[idx];

    if (row.variantType === 'color'){
      const cidx = (p.colors||[]).findIndex(c=> (c.name||c.color||'-') === row.variantLabel);
      if (cidx>-1){ p.colors[cidx].qty = Number(newQty)||0; }
    } else if (row.variantType === 'size'){
      const sidx = (p.sizes||[]).findIndex(s=> (s.name||s.size||'-') === row.variantLabel);
      if (sidx>-1){ p.sizes[sidx].qty = Number(newQty)||0; }
    } else {
      p.qty = Number(newQty)||0;
    }

    p.lastMod = Date.now();
    list[idx] = p;
    writeProducts(list);
    return true;
  }

  /* ==========================
     UI Rendering
  ========================== */
  const ROOT_ID = 'inventory-root';

  function ensureRoot(){
    let root = document.getElementById(ROOT_ID);
    if (!root){
      // يُحقن داخل تبويب إدارة المخزون
      const panel = document.getElementById('tab-inventory') || document.createElement('section');
      panel.id = 'tab-inventory';
      panel.className = 'tab-panel';
      panel.setAttribute('role','tabpanel');
      panel.innerHTML = `<div id="${ROOT_ID}"></div>`;
      if (!panel.parentElement){
        (document.querySelector('main')||document.body).appendChild(panel);
      }
      root = document.getElementById(ROOT_ID);
    }
    return root;
  }

  function render(){
    const root = ensureRoot();
    const rows = deriveRows();

    const sections = [ ...new Set(rows.map(r=> r.section||'غير مصنّف')) ];
    const cats     = [ ...new Set(rows.map(r=> r.category||'غير مصنّف')) ];

    root.innerHTML = `
      <div class="inv-toolbar">
        <div class="inv-filters">
          <input id="invSearch" class="input" type="search" placeholder="بحث بالاسم أو SKU" autocomplete="off" />
          <select id="invSection">
            <option value="">كل الأقسام</option>
            ${sections.map(s=>`<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('')}
          </select>
          <select id="invCategory">
            <option value="">كل الفئات</option>
            ${cats.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('')}
          </select>
          <button id="invExport" class="btn btn--ghost">🗂️ تصدير CSV</button>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table--compact" id="invTable">
          <thead>
            <tr>
              <th>المنتج</th>
              <th>SKU</th>
              <th>القسم</th>
              <th>الفئة</th>
              <th>اللون/المقاس</th>
              <th>السعر</th>
              <th>الكمية</th>
              <th>الحالة</th>
              <th>آخر تعديل</th>
              <th>إجراءات</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map(rowToTr).join('')}
          </tbody>
        </table>
      </div>

      <dialog id="dlgInv" class="modal__dialog--simple">
        <form method="dialog" id="invForm" class="inv-form">
          <h3>تعديل الكمية</h3>
          <div class="grid grid-2">
            <label>العملية
              <select id="invOp" required>
                <option value="add">+ إضافة</option>
                <option value="sub">− خصم</option>
              </select>
            </label>
            <label>الكمية
              <input id="invAmount" type="number" min="1" step="1" placeholder="1" required />
            </label>
          </div>
          <label>ملاحظة (اختياري)
            <input id="invNote" type="text" maxlength="120" placeholder="سبب التعديل" />
          </label>
          <div class="form-actions">
            <button type="submit" class="btn">حفظ</button>
            <button type="button" id="invCancel" class="btn btn--ghost">إلغاء</button>
          </div>
        </form>
      </dialog>

      <dialog id="dlgLog" class="modal__dialog--simple">
        <div class="inv-log">
          <div class="log-head">
            <h3>سجل التعديلات</h3>
            <button id="closeLog" class="btn btn--ghost">إغلاق</button>
          </div>
          <div id="logBody" class="log-body"></div>
        </div>
      </dialog>
    `;

    bindToolbar();
    bindTable();
    bindDialogs();
  }

  function escapeHtml(s){
    return String(s??'').replace(/[&<>\"']/g, ch=> ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[ch]));
  }

  function rowToTr(r){
    return `
      <tr data-row-id="${r.rowId}">
        <td><div class="stack">
          <strong>${escapeHtml(r.name)}</strong>
          <small class="muted">${r.type==='colors'?'متعدد الألوان': r.type==='sizes'?'متعدد الأحجام':'عادي'}</small>
        </div></td>
        <td><code>${escapeHtml(r.sku)}</code></td>
        <td>${escapeHtml(r.section||'-')}</td>
        <td>${escapeHtml(r.category||'-')}</td>
        <td>${escapeHtml(r.variantType? r.variantLabel : '-')}</td>
        <td>${fmtMoney(r.price)}</td>
        <td><strong>${Number(r.qty||0)}</strong></td>
        <td>${statusChip(r.status)}</td>
        <td><small>${r.lastMod? fmtDate(r.lastMod) : '-'}</small></td>
        <td>
          <div class="btns">
            <button class="btn btn--sm" data-act="edit">تعديل</button>
            <button class="btn btn--sm btn--ghost" data-act="log">السجل</button>
          </div>
        </td>
      </tr>`;
  }

  /* ==========================
     Bindings
  ========================== */
  let currentEditRow = null; // آخر صف مختار للتعديل

  function bindToolbar(){
    const root = ensureRoot();
    const search = $('#invSearch', root);
    const secSel = $('#invSection', root);
    const catSel = $('#invCategory', root);
    const exportBtn = $('#invExport', root);

    const apply = ()=> {
      const q  = (search.value||'').trim().toLowerCase();
      const sf = (secSel.value||'').toLowerCase();
      const cf = (catSel.value||'').toLowerCase();
      const tbody = $('#invTable tbody', root);
      const all = $$('tr', tbody);
      all.forEach(tr=>{
        const tds = $$('td', tr).map(td=> td.textContent.trim().toLowerCase());
        const matchesQ = !q || tds.some(t=> t.includes(q));
        const sec = tds[2]||''; // القسم
        const cat = tds[3]||''; // الفئة
        const matchesS = !sf || sec === sf;
        const matchesC = !cf || cat === cf;
        tr.style.display = (matchesQ && matchesS && matchesC) ? '' : 'none';
      });
    };

    ['input','change','keyup'].forEach(ev=> search.addEventListener(ev, apply));
    secSel.addEventListener('change', apply);
    catSel.addEventListener('change', apply);
    exportBtn.addEventListener('click', exportCSV);
  }

  function bindTable(){
    const root = ensureRoot();
    const tbody = $('#invTable tbody', root);
    tbody.addEventListener('click', (e)=>{
      const btn = e.target.closest('button[data-act]');
      if (!btn) return;
      const tr = e.target.closest('tr');
      const rowId = tr?.getAttribute('data-row-id');
      if (!rowId) return;
      const row = deriveRows().find(r=> r.rowId === rowId);
      if (!row) return;

      if (btn.dataset.act === 'edit'){
        currentEditRow = row;
        openEditDialog(row);
      } else if (btn.dataset.act === 'log'){
        openLogDialog(row);
      }
    });
  }

  function bindDialogs(){
    const root = ensureRoot();
    const dlg  = $('#dlgInv', root);
    const form = $('#invForm', root);
    const cancel = $('#invCancel', root);

    cancel.addEventListener('click', ()=> dlg.close());

    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      if (!currentEditRow) return;
      const op   = $('#invOp', form).value;
      const amt  = Math.max(1, Math.floor(Number($('#invAmount', form).value||0)));
      const note = ($('#invNote', form).value||'').trim();

      const newQty = Math.max(0, (op==='add' ? currentEditRow.qty + amt : currentEditRow.qty - amt));
      const delta  = (op==='add' ? +amt : -amt);

      if (writeQtyBack(currentEditRow, newQty)){
        pushInvLog({
          ts: Date.now(),
          sku: currentEditRow.sku,
          variantType: currentEditRow.variantType,
          variantLabel: currentEditRow.variantLabel,
          before: currentEditRow.qty,
          change: delta,
          after: newQty,
          note,
        });
        dlg.close();
        toast('تم حفظ تعديل الكمية.');
        render();
      } else {
        toast('تعذّر تحديث الكمية لهذا الصف.', 'error');
      }
    });

    const dlgLog = $('#dlgLog', root);
    $('#closeLog', root).addEventListener('click', ()=> dlgLog.close());
  }

  /* ==========================
     Dialogs
  ========================== */
  function openEditDialog(row){
    const root = ensureRoot();
    const dlg  = $('#dlgInv', root);
    const form = $('#invForm', root);
    $('#invOp', form).value = 'add';
    $('#invAmount', form).value = '1';
    $('#invNote', form).value = '';
    try{ dlg.showModal(); }catch{ dlg.setAttribute('open','true'); }
  }

  function openLogDialog(row){
    const root = ensureRoot();
    const dlg  = $('#dlgLog', root);
    const out  = $('#logBody', root);
    const all  = readInvLog().filter(x=> x.sku === row.sku && (row.variantType? x.variantLabel===row.variantLabel : true));
    if (!all.length){ out.innerHTML = '<p class="muted">لا يوجد سجل تعديلات لهذا العنصر.</p>'; }
    else {
      out.innerHTML = `
        <div class="table-responsive">
          <table class="table table--compact">
            <thead>
              <tr>
                <th>الوقت</th>
                <th>SKU</th>
                <th>اللون/المقاس</th>
                <th>قبل</th>
                <th>التغيير</th>
                <th>بعد</th>
                <th>ملاحظة</th>
              </tr>
            </thead>
            <tbody>
              ${all.map(l=>`<tr>
                <td>${fmtDate(l.ts)}</td>
                <td><code>${escapeHtml(l.sku)}</code></td>
                <td>${escapeHtml(l.variantLabel||'-')}</td>
                <td>${Number(l.before||0)}</td>
                <td>${l.change>0? '＋'+l.change : '−'+Math.abs(l.change)}</td>
                <td>${Number(l.after||0)}</td>
                <td>${escapeHtml(l.note||'')}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
    }
    try{ dlg.showModal(); }catch{ dlg.setAttribute('open','true'); }
  }

  /* ==========================
     CSV Export
  ========================== */
  function exportCSV(){
    const rows = deriveRows();
    const headers = ['المنتج','SKU','القسم','الفئة','اللون/المقاس','السعر','الكمية','الحالة','آخر_تعديل'];
    const lines = [headers.join(',')];
    for (const r of rows){
      lines.push([
        qcsv(r.name),
        qcsv(r.sku),
        qcsv(r.section||''),
        qcsv(r.category||''),
        qcsv(r.variantType? r.variantLabel : ''),
        qcsv(String(r.price)),
        qcsv(String(r.qty)),
        qcsv(r.status),
        qcsv(r.lastMod? new Date(r.lastMod).toISOString() : ''),
      ].join(','));
    }
    const blob = new Blob(["\ufeff"+lines.join('\n')], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'inventory.csv'; a.click();
    setTimeout(()=> URL.revokeObjectURL(url), 2000);
  }
  const qcsv = (s)=> '"'+String(s??'').replace(/"/g,'""')+'"';

  /* ==========================
     Minimal Styles (scoped)
  ========================== */
  addScopedStyles();
  function addScopedStyles(){
    const css = `
    #${ROOT_ID} { display: grid; gap: 12px; }
    #${ROOT_ID} .inv-toolbar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; justify-content: space-between; }
    #${ROOT_ID} .inv-filters { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    #${ROOT_ID} .input { padding: 8px 10px; border: 1px solid var(--border,#d1d5db); border-radius: 10px; background: var(--bg-elev,#11182714); color: inherit; }
    #${ROOT_ID} select { padding: 8px 10px; border-radius: 10px; }
    #${ROOT_ID} .btn { padding: 8px 12px; border-radius: 10px; border: 1px solid transparent; cursor: pointer; }
    #${ROOT_ID} .btn--ghost { background: transparent; border-color: var(--border,#374151); }
    #${ROOT_ID} .btn--sm { padding: 6px 10px; border-radius: 8px; }
    #${ROOT_ID} .table { width: 100%; border-collapse: collapse; }
    #${ROOT_ID} .table th, #${ROOT_ID} .table td { padding: 10px; border-bottom: 1px solid var(--border,#1f2937); text-align: right; }
    #${ROOT_ID} .table--compact th, #${ROOT_ID} .table--compact td { padding: 8px; }
    #${ROOT_ID} .table-responsive { overflow:auto; border-radius: 14px; }
    #${ROOT_ID} .muted { opacity: .7; }
    #${ROOT_ID} .stack { display: grid; gap: 2px; }
    #${ROOT_ID} .chip { display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border-radius: 999px; font-size: 12px; }
    #${ROOT_ID} .chip--available { background: #064e3b; color: #d1fae5; }
    #${ROOT_ID} .chip--low { background: #78350f; color: #ffedd5; }
    #${ROOT_ID} .chip--almost { background: #7c2d12; color: #ffddd2; }
    #${ROOT_ID} .chip--out { background: #374151; color: #d1d5db; }

    /* dialogs */
    #${ROOT_ID} dialog[open] { border: none; border-radius: 16px; padding: 16px; background: var(--bg-card,#111827); color: inherit; max-width: 520px; width: calc(100% - 32px); }
    #${ROOT_ID} .grid { display: grid; gap: 8px; }
    #${ROOT_ID} .grid-2 { grid-template-columns: repeat(2, minmax(0,1fr)); }
    @media (max-width:720px){ #${ROOT_ID} .grid-2 { grid-template-columns: 1fr; } }
    #${ROOT_ID} .form-actions { display:flex; gap:8px; justify-content:flex-end; margin-top: 10px; }

    /* buttons group */
    #${ROOT_ID} .btns { display:flex; gap:6px; }
    `;
    const id = 'inv-scoped-styles';
    if (!document.getElementById(id)){
      const style = document.createElement('style');
      style.id = id; style.innerHTML = css; document.head.appendChild(style);
    }
  }

  /* ==========================
     Boot
  ========================== */
  function boot(){ render(); }
  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  } else { boot(); }

})();
