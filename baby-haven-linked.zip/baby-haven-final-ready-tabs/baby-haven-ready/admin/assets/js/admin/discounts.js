// # Header Block
// File: assets/js/admin/discounts.js
// Purpose: نظام الخصومات — واجهة مبسطة + واجهات API للقراءة
(function(){
  "use strict";
  const root = document.getElementById('tab-discounts'); if (!root) return;
  root.innerHTML = `<p class="muted">خصومات المنتج/الطلب/التوصيل — نموذج مبسّط للتسليم. تستخدمه الواجهة عبر BH_getDiscountAPI().</p>`;

  const STORE = {
    products: [],  // [{sku:'BH-TOY-0001', percent:10, expires:'2025-12-31'}]
    orders:   [],  // [{type:'percent', value:5}]
    shipping: []   // [{type:'flat', value:1}]
  };

  window.BH_discounts = {
    evaluateOrderDiscount(subTotal){
      const p = STORE.orders[0]; if(!p) return null;
      if (p.type==='percent') return {amount: +(subTotal*(p.value/100)).toFixed(3)};
      if (p.type==='flat') return {amount: +p.value};
      return null;
    },
    findProductDiscountForSKU(sku){
      return STORE.products.find(x=> x.sku===sku) || null;
    }
  };
})();