
/* =======================================================
   Baby Haven — Admin Core (Tabs Controller)
   Roles: click + keyboard navigation + URL hash + persistence
======================================================= */
(function(){
  "use strict";

  function $(sel, root){ return (root||document).querySelector(sel); }
  function $$(sel, root){ return Array.from((root||document).querySelectorAll(sel)); }

  const TAB_HASH_KEY = 'bh_admin_tab';

  function getPairs(){
    const tabs = $$('[role="tab"]');
    const panels = $$('[role="tabpanel"]');
    const map = new Map();
    tabs.forEach(tab => {
      let cid = tab.getAttribute('aria-controls');
      if (!cid) {
        // try to infer from id pattern: tab-xyz -> panel-xyz
        const tid = tab.id || '';
        const guess = tid.replace(/^tab-/, 'panel-');
        if (guess && $('#'+guess)) {
          cid = guess;
          tab.setAttribute('aria-controls', cid);
        }
      }
      if (cid) {
        const panel = document.getElementById(cid);
        if (panel) map.set(tab, panel);
      }
    });
    return { tabs: Array.from(map.keys()), panels: Array.from(map.values()), map };
  }

  function deactivateAll(tabs, panels){
    tabs.forEach(t => {
      t.setAttribute('aria-selected','false');
      t.setAttribute('tabindex','-1');
      t.classList.remove('is-active');
    });
    panels.forEach(p => {
      p.setAttribute('hidden','');
      p.setAttribute('aria-hidden','true');
    });
  }

  function activateTab(tab, tabs, panels, map, opts){
    const panel = map.get(tab);
    if (!panel) return;
    deactivateAll(tabs, panels);
    tab.setAttribute('aria-selected','true');
    tab.setAttribute('tabindex','0');
    tab.classList.add('is-active');
    panel.removeAttribute('hidden');
    panel.setAttribute('aria-hidden','false');
    // focus for accessibility when keyboard-activated
    if (opts && opts.focus) tab.focus();
    // update URL hash: #tab=<id-without-prefix>
    const id = tab.id || '';
    try {
      const key = id.replace(/^tab-/, '') || panel.id.replace(/^panel-/, '');
      if (key) history.replaceState(null, '', '#tab=' + encodeURIComponent(key));
    } catch(e){/* ignore */}
    // persist
    try {
      localStorage.setItem(TAB_HASH_KEY, tab.id || panel.id);
    } catch(e){/* ignore */}
  }

  function findInitialTab(tabs){
    // 1) URL hash: #tab=xyz
    const h = (location.hash || '').replace(/^#/, '');
    const m = h.match(/tab=([^&]+)/);
    if (m) {
      const key = decodeURIComponent(m[1]);
      const byId = document.getElementById('tab-' + key) || document.getElementById('panel-' + key);
      if (byId) {
        // if a panel id, find owner tab
        if (byId.getAttribute('role') === 'tabpanel') {
          const pid = byId.id;
          const t = $$('[role="tab"]').find(tb => tb.getAttribute('aria-controls') === pid);
          if (t) return t;
        }
        if (byId.getAttribute('role') === 'tab') return byId;
      }
    }
    // 2) localStorage
    try {
      const saved = localStorage.getItem(TAB_HASH_KEY);
      if (saved) {
        const t = document.getElementById(saved);
        if (t && t.getAttribute('role') === 'tab') return t;
      }
    } catch(e){/* ignore */}
    // 3) first tab marked aria-selected=true
    const pre = $$('[role="tab"]').find(t => t.getAttribute('aria-selected') === 'true');
    if (pre) return pre;
    // 4) fallback: first tab in DOM
    return $$('[role="tab"]')[0] || null;
  }

  function moveFocus(tabs, current, dir){
    if (!tabs.length) return;
    const i = Math.max(0, tabs.indexOf(current));
    const j = (i + dir + tabs.length) % tabs.length;
    tabs[j].focus();
  }

  function onKeyDown(e, tabs, panels, map){
    const k = e.key;
    const current = document.activeElement;
    if (!current || current.getAttribute('role') !== 'tab') return;
    switch(k){
      case 'ArrowRight':
      case 'ArrowDown':
        e.preventDefault(); moveFocus(tabs, current, +1); break;
      case 'ArrowLeft':
      case 'ArrowUp':
        e.preventDefault(); moveFocus(tabs, current, -1); break;
      case 'Home':
        e.preventDefault(); tabs[0] && tabs[0].focus(); break;
      case 'End':
        e.preventDefault(); tabs[tabs.length-1] && tabs[tabs.length-1].focus(); break;
      case 'Enter':
      case ' ':
        e.preventDefault(); activateTab(current, tabs, panels, map, {focus:true}); break;
    }
  }

  function initTabs(){
    const {tabs, panels, map} = getPairs();
    if (!tabs.length || !panels.length) return;

    // Ensure required ARIA defaults
    tabs.forEach((t, i) => {
      if (!t.id) t.id = 'tab-' + (i+1);
      t.setAttribute('role','tab');
      t.setAttribute('tabindex', t.getAttribute('aria-selected')==='true' ? '0' : '-1');
    });
    panels.forEach((p, i) => {
      if (!p.id) p.id = 'panel-' + (i+1);
      p.setAttribute('role','tabpanel');
      p.setAttribute('tabindex','0');
      p.setAttribute('aria-hidden', p.hasAttribute('hidden') ? 'true' : 'false');
    });

    // Activate initial
    const first = findInitialTab(tabs) || tabs[0];
    activateTab(first, tabs, panels, map, {focus:false});

    // Click support
    document.addEventListener('click', (e)=>{
      const btn = e.target.closest('[role="tab"]');
      if (!btn || !map.has(btn)) return;
      e.preventDefault();
      activateTab(btn, tabs, panels, map, {focus:false});
    });

    // Keyboard support
    document.addEventListener('keydown', (e)=> onKeyDown(e, tabs, panels, map));

    // If hash changes externally
    window.addEventListener('hashchange', ()=>{
      const target = findInitialTab(tabs);
      if (target) activateTab(target, tabs, panels, map, {focus:false});
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTabs);
  } else {
    initTabs();
  }
})();
