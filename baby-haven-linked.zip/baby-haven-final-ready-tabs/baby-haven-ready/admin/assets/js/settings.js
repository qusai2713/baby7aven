/* =======================================================
📁 File: assets/js/settings.js
⚙️ تبويب الإعدادات: حفظ/قراءة + تصدير/استيراد
======================================================= */

(function () {
  "use strict";

  const { $, toast } = window.BH;

  const KEY = "bh_settings";

  // قيم افتراضية
  const defaults = {
    storeName: "Baby Haven",
    supportEmail: "",
    currency: "OMR",
    tax: 0,
    thawani: {
      publicKey: "",
      secretKey: "",  // ملاحظة: لا يُستخدم في الواجهة، فقط للحفظ المرجعي (الخادوم الوسيط يستعمله)
      mode: "UAT",    // UAT | LIVE
      backendUrl: ""  // رابط خادومك الوسيط (API Base)
    }
  };

  // قراءة/كتابة
  function read() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || JSON.stringify(defaults));
    } catch {
      return { ...defaults };
    }
  }
  function write(data) {
    localStorage.setItem(KEY, JSON.stringify(data));
  }

  // تعبئة الحقول من التخزين
  function fillForm() {
    const st = read();
    $("#stName").value = st.storeName || "";
    $("#stSupportEmail").value = st.supportEmail || "";
    $("#stCurrency").value = st.currency || "OMR";
    $("#stTax").value = Number(st.tax || 0);

    $("#stThawaniPub").value = st.thawani?.publicKey || "";
    $("#stThawaniSec").value = st.thawani?.secretKey || "";
    $("#stThawaniMode").value = st.thawani?.mode || "UAT";
    $("#stBackendUrl").value = st.thawani?.backendUrl || "";
  }

  // قراءة القيم من الحقول
  function readForm() {
    return {
      storeName: ($("#stName").value || "").trim(),
      supportEmail: ($("#stSupportEmail").value || "").trim(),
      currency: $("#stCurrency").value || "OMR",
      tax: Number($("#stTax").value || 0),
      thawani: {
        publicKey: ($("#stThawaniPub").value || "").trim(),
        secretKey: ($("#stThawaniSec").value || "").trim(),
        mode: $("#stThawaniMode").value || "UAT",
        backendUrl: ($("#stBackendUrl").value || "").trim(),
      }
    };
  }

  // تحقق أساسي
  function validate(st) {
    if (!st.storeName) return "أدخل اسم المتجر";
    if (st.supportEmail && !/^\S+@\S+\.\S+$/.test(st.supportEmail)) return "بريد الدعم غير صالح";
    if (!st.thawani.backendUrl) return "أدخل رابط خادومك الوسيط (API Base)";
    if (!/^https?:\/\//i.test(st.thawani.backendUrl)) return "رابط الخادوم غير صالح (يجب أن يبدأ بـ http/https)";
    // مفاتيح ثواني اختيارية الآن، لكن ننبه إن كانت ناقصة عند محاولة الدفع من الواجهة.
    return null;
  }

  // حفظ
  $("#btnSettingsSave")?.addEventListener("click", () => {
    const st = readForm();
    const err = validate(st);
    if (err) return toast(err);
    write(st);
    toast("تم حفظ الإعدادات");
  });

  // تصدير
  $("#btnSettingsExport")?.addEventListener("click", () => {
    const st = read();
    const blob = new Blob([JSON.stringify(st, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "settings-export.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 0);
    toast("تم تصدير الإعدادات");
  });

  // استيراد
  $("#btnSettingsImport")?.addEventListener("click", () => $("#fileSettingsImport").click());
  $("#fileSettingsImport")?.addEventListener("change", function () {
    const f = this.files && this.files[0];
    if (!f) return;
    const fr = new FileReader();
    fr.onload = (e) => {
      try {
        const obj = JSON.parse(String(e.target.result || "{}"));
        const merged = {
          ...defaults,
          ...obj,
          thawani: { ...defaults.thawani, ...(obj.thawani || {}) }
        };
        const err = validate(merged);
        if (err) return toast(err);
        write(merged);
        fillForm();
        toast("تم الاستيراد والحفظ");
      } catch {
        toast("فشل الاستيراد: تحقق من صيغة الملف");
      } finally {
        this.value = "";
      }
    };
    fr.readAsText(f);
  });

  // تحميل أولي
  document.addEventListener("DOMContentLoaded", fillForm);
})();
