/* -------------------------------------------------------------
# Header Block
File: assets/js/storefront-bridge.js
Purpose: ربط الواجهة مع بيانات لوحة التحكم (LocalStorage) + مزامنة حية
------------------------------------------------------------- */
(function(w){
  'use strict';
  var ADMIN_KEY = 'bh_products';               // ما يكتبه admin
  var STORE_KEY = (w.StoreDB && w.StoreDB.KEY_PRODUCTS) || 'bh_admin_products_v35';

  function readLS(key, fallback){
    try{ return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
    catch(_){ return fallback; }
  }
  function writeLS(key, val){ localStorage.setItem(key, JSON.stringify(val)); }

  // اجلب المنتجات من المفتاح الإداري
  function getProducts(){
    var a = readLS(ADMIN_KEY, []);
    // حافظ على توافق الرسومات القديمة التي تقرأ من STORE_KEY
    writeLS(STORE_KEY, a);
    return a;
  }

  // توفير API بسيط عالمي
  w.BH_data = w.BH_data || {};
  w.BH_data.getProducts = getProducts;
  w.BH_data.subscribe = function(cb){
    if(typeof cb!=='function') return ()=>{};
    var handler = function(ev){
      if(ev && ev.key && (ev.key===ADMIN_KEY || ev.key===STORE_KEY)){
        try{ cb(getProducts()); }catch(e){ /* no-op */ }
      }
    };
    w.addEventListener('storage', handler);
    return function(){ w.removeEventListener('storage', handler); };
  };

  // مزامنة فورية أول تشغيل (حتى تعمل StoreDB الحالية بسلاسة)
  try { writeLS(STORE_KEY, getProducts()); } catch(e){/* ignore */}

})(window);
