# Baby Haven — Ready Project (Skeleton)
Generated: 2025-10-06 03:17

This package contains a complete file/folder split for:
- Admin Panel (products, categories, settings incl. Thawani keys)
- Storefront (home, products list, product details, cart, checkout, thank-you)

DATA (localStorage keys):
- bh_admin_products_v35 (products)
- bh_sections_v10 (sections)
- bh_categories_v10 (categories)
- bh_settings (general settings & payment keys)

Start here:
1) Open `admin/admin.html` to manage data/settings.
2) Open `web/index.html` to browse the storefront.

All JS/CSS files are stubs with TODO markers so you can wire your existing UI/code quickly.
